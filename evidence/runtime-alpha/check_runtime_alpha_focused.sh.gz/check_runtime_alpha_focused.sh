#!/usr/bin/env bash
set -euo pipefail
export PATH="$PATH:/mnt/niva-array/nsbu-solver/work/rust-tools/bin"
rust-code-analysis-cli -p crates -m -O json > ../runtime-alpha-rca.json
cargo +nightly-2026-03-03 llvm-cov -p nsbu-benchmarks --test v2_run --test v2_run_allocation --test v2_archive --test v2_archive_negative --test v2_observer --test runtime_force --test smooth_observer --test reconstruction_observer --branch --no-report > ../runtime-alpha-focused-coverage-tests.log 2>&1
cargo +nightly-2026-03-03 llvm-cov -p nsbu-cli --all-targets --branch --no-report >> ../runtime-alpha-focused-coverage-tests.log 2>&1
cargo +nightly-2026-03-03 llvm-cov report --json --no-default-ignore-filename-regex --ignore-filename-regex '(/rustc/|/\.cargo/registry/|/\.rustup/toolchains/|/target/)' --output-path ../runtime-alpha-focused-coverage.json > ../runtime-alpha-focused-report.log 2>&1
rg '(v2_run|runtime_force|v2_observer|v2_archive|nsbu-cli)' ../runtime-alpha-rca.json > ../runtime-alpha-focused-metrics.json
/mnt/niva-array/nsbu-solver/.venv/bin/python quality/check_crap.py rust ../runtime-alpha-focused-metrics.json ../runtime-alpha-focused-coverage.json ../runtime-alpha-focused-crap.json > ../runtime-alpha-focused-crap.log 2>&1
