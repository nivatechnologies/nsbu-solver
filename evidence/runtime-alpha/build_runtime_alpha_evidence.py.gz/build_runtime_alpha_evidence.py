"""Assemble alpha evidence only after the final local validation outputs exist."""
import datetime, gzip, hashlib, json, platform, re, subprocess, tomllib
from pathlib import Path

root = Path('/mnt/niva-array/nsbu-solver/work/runtime-alpha-development')
work = root.parent
out = root / 'evidence/runtime-alpha'
sha = lambda data: hashlib.sha256(data).hexdigest()

def load(suffix):
    return json.loads((work / ('runtime-alpha-' + suffix)).read_text())

def write(name, value):
    (out / name).write_text(json.dumps(value, indent=2) + '\n')

def spaces(space):
    yield space
    for child in space['spaces']:
        yield from spaces(child)

source = {str(p.relative_to(root)): sha(p.read_bytes())
          for directory in ('crates', 'reference', 'quality', 'tools', 'typings')
          for p in (root / directory).rglob('*') if p.suffix in ('.rs', '.py', '.pyi')}
rust = [p for p in source if p.endswith('.rs')]
python = [p for p in source if not p.endswith('.rs')]
assert (len(rust), len(python)) == (332, 98)
assert {p: source[p] for p in rust} == json.loads((out / 'runtime-source-sha256.json').read_text())
assert all(source[p] == json.loads((out / 'python-source-reuse.json').read_text())['source_sha256'][p] for p in python)
measured = [s for line in (work / 'runtime-alpha-metrics-final.json').read_text().splitlines()
            for s in spaces(json.loads(line))]
functions = [s for s in measured if s['kind'] == 'function']
maxima = {'cyclomatic': max(s['metrics']['cyclomatic']['sum'] for s in functions),
          'cognitive': max(s['metrics']['cognitive']['sum'] for s in functions),
          'halstead_function_and_file': max(s['metrics']['halstead']['difficulty'] or 0 for s in measured),
          'physical_file_lines': max(len((root / p).read_text().splitlines()) for p in rust),
          'crap': load('rust-crap.json')['maximum']}
for key, limit in [('cyclomatic', 22), ('cognitive', 22), ('halstead_function_and_file', 80), ('physical_file_lines', 500), ('crap', 25)]:
    assert maxima[key] < limit, (key, maxima[key])
coverage = load('coverage.json')['data'][0]['totals']
assert coverage['lines']['percent'] >= 80 and coverage['branches']['percent'] >= 80
log = (work / 'runtime-alpha-full-rust-tests.log').read_text()
assert 'test result: FAILED' not in log
harness = sum(map(int, re.findall(r'test result: ok\. (\d+) passed', log)))
assert harness == 425, harness
allocation_executables = sum(test.get('harness') is False for p in (root / 'crates').glob('*/Cargo.toml') for test in tomllib.loads(p.read_text()).get('test', []))
assert allocation_executables == 9
assert not (work / 'runtime-alpha-type-escapes.log').read_bytes()
clean = load('clean-summary.json')
assert clean['rust_source_hash_count'] == 332 and clean['python_reuse_hash_count'] == 98
assert all(clean[key] == 'passed' for key in ['repository_checks', 'design_checks', 'cargo_package', 'cargo_install', 'installed_help_version'])
assert clean['cm_completed'] and clean['ho_completed'] and clean['ho_resume_completed']
artifacts = {}

def archive(path, name):
    raw = path.read_bytes()
    packed = gzip.compress(raw, mtime=0)
    filename = name + '.gz'
    (out / filename).write_bytes(packed)
    artifacts[filename] = {'bytes': len(packed), 'sha256': sha(packed),
                           'uncompressed_bytes': len(raw), 'uncompressed_sha256': sha(raw)}

for suffix in ['coverage.json', 'metrics-final.json', 'rust-crap.json', 'full-rust-tests.log',
               'clippy-final.log', 'format-final.log', 'rustdoc-final.log', 'doctests-final.log',
               'bootstrap-tests.log', 'repository-check-initial.log', 'repository-check-final.log', 'design.log',
               'runtime-tests.log', 'negative-final.log', 'observer-tests.log',
               'cli-tests-final.log', 'focused-coverage-tests.log', 'focused-coverage.json',
               'focused-metrics.json', 'focused-crap.json', 'clean-checks.log',
               'clean-package.log', 'clean-install.log', 'clean-smoke.log',
               'clean-summary.json', 'clean-path-manifest.json', 'dead-code.log',
               'type-escapes.log', 'source-files.txt', 'release-build.log', 'bundle-check.log', 'bundle-summary.json']:
    archive(work / ('runtime-alpha-' + suffix), suffix)
for name in ['cm', 'ho', 'ho-checkpoint', 'ho-resume']:
    write('clean-' + name + '.json', load('clean-' + name + '.json'))
for name in ['base-hosted-rust', 'base-hosted-python']:
    data = load(name + '.json'); assert data['conclusion'] == 'success'
    write(name + '.json', data)
archive(work / 'runtime-alpha-duplicates/jscpd-report.json', 'duplicates.json')
for script in ['check_runtime_alpha_rust.sh', 'check_runtime_alpha_focused.sh', 'build_runtime_alpha_evidence.py', 'check_alpha_bundle.py']:
    archive(work / script, script)
write('public-repository.json', load('public-repository.json'))
write('source-sha256.json', source)
write('artifact-sha256.json', artifacts)
unused = sorted(set(re.findall(r'^warning: (.+(?:never used|never read).*)$',
                             (work / 'runtime-alpha-dead-code.log').read_text(), re.M)))
summary = {
 'increment': 'usable exact-v2 runtime alpha', 'generated_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'status': 'all local runtime, quality and clean-install gates passed; source-matched hosted CI required before publication',
 'source_implementation_commit': '672a0dd', 'clean_checkout_commit': clean['source_commit'],
 'source_inventory': 'source-sha256.json', 'rust_source_files': len(rust), 'python_source_files': len(python),
 'rust_harness_tests': harness, 'rust_allocation_executables': 9, 'rust_tests_and_probes': harness + 9,
 'rust_coverage': coverage, 'rust_maxima': maxima,
 'python': {'maintained_sources_identical': 98, 'retained_full_test_profile': 220, 'bootstrap_tests_rerun': 41,
            'reference': 'python-source-reuse.json', 'frozen_math_rerun': True, 'hosted_full_suite_required': True},
 'runtime': {'case': 'similarity-mms-v2', 'methods': ['CM', 'HO'], 'initial_state': 'independently evolved from exact zero',
             'reference_assignments': 0, 'independent_dft_fixtures': 'N4 M4 full-band, 32 committed attempts, absolute coefficient tolerance 5e-13',
             'serial_parallel': 'all tested coefficient words, history and charged work identical',
             'checkpoint': 'CM and HO next committed step and full canonical archive match uninterrupted execution',
             'cli': 'default 32-step CM/HO, HO save after 16/resume to 32, exact remaining time and independently measured balances',
             'allocation': 'allocation-free admission and first/repeated committed steps; measured serial heap 193600 B under 260120 B plan',
             'resource_preflight': 'complete owner/provider/diagnostics/work history, final remaining-time restriction and checkpoint decode/input budgets',
             'transactional_refusals': 'rejected/refused attempts retain spent work and last committed physical state; terminal status survives import'},
 'clean_install': clean, 'execution_profile': {'rust': '1.94.0', 'coverage_toolchain': 'nightly-2026-03-03',
       'cargo_llvm_cov': '0.9.1', 'rust_code_analysis': '0.0.25', 'host': platform.platform(),
       'cargo_lock_sha256': sha((root / 'Cargo.lock').read_bytes()),
       'cargo_manifest_sha256': {str(p.relative_to(root)): sha(p.read_bytes()) for p in [root / 'Cargo.toml', *(root / 'crates').glob('*/Cargo.toml')]},
       'rust_toolchain_sha256': sha((root / 'rust-toolchain.toml').read_bytes()),
       'test_profile': {'opt_level': 2, 'debug_assertions': True, 'overflow_checks': True}},
 'informational_findings': {'duplicates': load('duplicates/jscpd-report.json')['statistics']['total'],
       'distinct_unused_helper_warning_labels': unused, 'type_escape_identifiers': 0,
       'mutations': 'Not rerun for alpha; earlier mutation reports retained as informational evidence.'},
 'solid_review': 'Admission, runtime ownership, force selection, diagnostics, checkpoint encoding/admission, CLI parsing/execution/reporting and release distribution have separate modules. The force adapter implements the existing PrescribedForce contract. Generic balance arithmetic is shared, while independent reference/DFT oracles are preserved.',
 'limitations': ['Coarse N4 force and spatial sampling do not establish PDE convergence.',
       'P08/P09 scientific qualification and P10 accepted concentrating windows remain incomplete.',
       'Checkpoint word equivalence is scoped to the tested build/environment; compiler and processor identity are not authenticated by the v2 container.',
       'Worker stack/native reservations are execution-profile planning allowances, not universal OS RSS bounds.',
       'Literal source reproduction, mathematics compiler, averaged-stress surrogate, Niva adapter and visualization are outside this alpha.'],
 'accepted_pde_windows': 0, 'artifact_inventory': 'artifact-sha256.json'}
write('summary.json', summary)
print(json.dumps({'rust_tests_and_probes': harness + 9, 'maxima': maxima, 'coverage': coverage}, indent=2))
