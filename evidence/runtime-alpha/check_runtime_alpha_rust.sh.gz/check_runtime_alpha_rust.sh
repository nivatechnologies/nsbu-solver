#!/usr/bin/env bash
set -euo pipefail
export PATH="$PATH:/mnt/niva-array/nsbu-solver/work/rust-tools/bin"
cargo fmt --all -- --check > ../runtime-alpha-format-final.log 2>&1
cargo clippy --workspace --all-targets --locked -- -D warnings -A dead_code > ../runtime-alpha-clippy-final.log 2>&1
rust-code-analysis-cli -p crates -m -O json > ../runtime-alpha-metrics-final.json
jq -se '[.. | objects | select(.kind? == "function") | .metrics.cyclomatic.sum] | length > 0 and max < 22' ../runtime-alpha-metrics-final.json
jq -se '[.. | objects | select(.kind? == "function") | .metrics.cognitive.sum] | max < 22' ../runtime-alpha-metrics-final.json
jq -se '[.. | objects | select(has("metrics")) | .metrics.halstead.difficulty | select(. != null)] | max < 80' ../runtime-alpha-metrics-final.json
cargo +nightly-2026-03-03 llvm-cov --workspace --all-targets --branch --no-default-ignore-filename-regex --ignore-filename-regex '(/rustc/|/\.cargo/registry/|/\.rustup/toolchains/|/target/)' --json --output-path ../runtime-alpha-coverage.json > ../runtime-alpha-full-rust-tests.log 2>&1
/mnt/niva-array/nsbu-solver/.venv/bin/python quality/check_crap.py rust ../runtime-alpha-metrics-final.json ../runtime-alpha-coverage.json ../runtime-alpha-rust-crap.json > ../runtime-alpha-rust-crap.log 2>&1
jq -e '.data[0].totals | .lines.percent >= 80 and .branches.percent >= 80' ../runtime-alpha-coverage.json
RUSTDOCFLAGS='-D warnings' cargo doc --workspace --no-deps --locked > ../runtime-alpha-rustdoc-final.log 2>&1
cargo test --workspace --doc --locked > ../runtime-alpha-doctests-final.log 2>&1
