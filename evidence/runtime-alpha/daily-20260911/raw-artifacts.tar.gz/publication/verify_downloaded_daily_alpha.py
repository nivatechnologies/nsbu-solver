import hashlib,json,subprocess,tarfile
from pathlib import Path
work=Path('/mnt/niva-array/nsbu-solver/work')
folder=work/'daily-alpha-20260911'
name='nsbu-solver-alpha-20260911-x86_64-unknown-linux-gnu'
archive=folder/(name+'.tar.gz')
root=folder/name
with (work/'daily-alpha-20260911-downloaded-checks.log').open('w') as log:
    subprocess.run(['sha256sum','-c',name+'.tar.gz.sha256'],cwd=folder,check=True,stdout=log,stderr=subprocess.STDOUT)
    with tarfile.open(archive) as tar:
        tar.extractall(folder,filter='data')
    subprocess.run(['sha256sum','-c','SHA256SUMS'],cwd=root,check=True,stdout=log,stderr=subprocess.STDOUT)
    subprocess.run(['/mnt/niva-array/nsbu-solver/.venv/bin/python','tools/check_repository.py'],cwd=root,check=True,stdout=log,stderr=subprocess.STDOUT)
    binary=root/'bin/nsbu'
    for arg in ['--help','--version']:
        subprocess.run([str(binary),arg],check=True,stdout=log,stderr=subprocess.STDOUT)
    outputs={}
    checkpoint=folder/'downloaded-v2.chk'
    commands={'cm':['v2'],'ho':['v2','--method','ho'],'saved':['v2','--method','ho','--checkpoint',str(checkpoint),'--checkpoint-after','16'],'resumed':['resume-v2','--method','ho','--checkpoint',str(checkpoint)]}
    for label,args in commands.items():
        result=subprocess.run([str(binary),*args],check=True,stdout=subprocess.PIPE,stderr=log,text=True)
        output=json.loads(result.stdout)
        outputs[label]=output
        (work/f'daily-alpha-20260911-downloaded-{label}.json').write_text(json.dumps(output,indent=2)+'\n')
        print(label,output['status'],file=log,flush=True)
    for key in ['cm','ho','resumed']:
        assert outputs[key]['status']=='completed'
        assert outputs[key]['clock']['actual_elapsed_ticks']=='4096'
        assert outputs[key]['attempts']['committed']=='32'
        assert outputs[key]['qualification_status']=='unqualified'
        assert outputs[key]['accepted_pde_windows']==0
    assert outputs['saved']['status']=='checkpoint_saved'
    left=dict(outputs['ho']);right=dict(outputs['resumed'])
    assert left.pop('origin_status')=='internal_from_rest'
    assert right.pop('origin_status')=='external_unverified'
    assert left==right
    manifest=(root/'SOURCE-MANIFEST.txt').read_text()
    assert 'source_commit=6170341c42a64348c7d99bdfd4fc3653454f22a8\n' in manifest
result={'status':'passed','release_tag':'alpha-20260911','source_commit':'6170341c42a64348c7d99bdfd4fc3653454f22a8','archive_bytes':archive.stat().st_size,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'verified_files':len((root/'SHA256SUMS').read_text().splitlines()),'repository_checks':'passed','installed_methods':['CM','HO'],'committed_steps_each':32,'checkpoint_steps':16,'resumed_equals_uninterrupted_except_origin':True,'accepted_pde_windows':0,'manifest':manifest}
(work/'daily-alpha-20260911-downloaded-summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
