import json
import re
import sys
from pathlib import Path

binary, manifest_path, output = map(Path, sys.argv[1:])
manifest = dict(line.split("=", 1) for line in manifest_path.read_text().splitlines() if "=" in line)
import subprocess
versions = re.findall(r"GLIBC_(\d+)\.(\d+)", subprocess.run(["readelf", "--version-info", binary], text=True, stdout=subprocess.PIPE, check=True).stdout)
needed = re.findall(r"\(NEEDED\).*?\[(.*?)\]", subprocess.run(["readelf", "-d", binary], text=True, stdout=subprocess.PIPE, check=True).stdout)
maximum = max((int(a), int(b)) for a, b in versions)
assert maximum <= (2, 35)
assert set(needed) == set(manifest["needed_libraries"].split(","))
output.write_text(json.dumps({"maximum_glibc_symbol": f"GLIBC_{maximum[0]}.{maximum[1]}", "manifest_maximum": manifest["maximum_required_glibc_symbol"], "needed_libraries": needed, "manifest_needed_libraries": manifest["needed_libraries"].split(",")}, indent=2) + "\n")
