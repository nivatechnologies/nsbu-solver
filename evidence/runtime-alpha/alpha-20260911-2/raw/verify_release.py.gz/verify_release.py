#!/usr/bin/env python3
"""Independent verifier for the published alpha-20260911-2 archive.

Run only after publication.  It accepts local downloaded files, performs no download,
and keeps every output under the supplied --out directory.
"""
import argparse
import hashlib
import json
import re
import subprocess
import tarfile
import tempfile
from pathlib import Path, PurePosixPath

COMMIT = "88015d7681c6fb267c77d1454a3594f386d1d2ab"
VERSION = "0.1.0-alpha.1"
TAG = "alpha-20260911-2"
SHA = re.compile(r"^([0-9a-f]{64}) [ *]([^\t\n]+)$")


def run(args, cwd=None, capture=False):
    completed = subprocess.run(args, cwd=cwd, check=True, text=True,
                               stdout=subprocess.PIPE if capture else None)
    return completed.stdout if capture else None


def safe(name):
    path = PurePosixPath(name)
    return bool(name) and not path.is_absolute() and ".." not in path.parts and all(part not in ("", ".") for part in path.parts)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check_tar(archive, destination):
    with tarfile.open(archive, "r:gz") as tar:
        names = []
        for member in tar.getmembers():
            if not safe(member.name) or not (member.isfile() or member.isdir()):
                raise ValueError(f"unsafe archive member: {member.name}")
            if member.name in names:
                raise ValueError(f"duplicate archive member: {member.name}")
            names.append(member.name)
        roots = {PurePosixPath(name).parts[0] for name in names}
        if len(roots) != 1:
            raise ValueError(f"archive must have one root: {roots}")
        tar.extractall(destination, filter="data")
        return destination / roots.pop()


def check_sums(root, source_files):
    lines = (root / "SHA256SUMS").read_text().splitlines()
    seen = set()
    for line in lines:
        match = SHA.fullmatch(line)
        if not match or not safe(match.group(2)) or match.group(2) in seen:
            raise ValueError(f"unsafe SHA256SUMS entry: {line!r}")
        seen.add(match.group(2))
        path = root / match.group(2)
        if not path.is_file() or digest(path) != match.group(1):
            raise ValueError(f"checksum mismatch: {match.group(2)}")
    expected = set(source_files) | {"bin/nsbu", "SOURCE-MANIFEST.txt"}
    if seen != expected:
        raise ValueError("SHA256SUMS inventory does not exactly match source files plus release artifacts")
    actual = {path.relative_to(root).as_posix() for path in root.rglob("*") if path.is_file()}
    if actual != seen | {"SHA256SUMS"}:
        raise ValueError("archive files do not exactly match SHA256SUMS inventory")
    return len(lines)


def manifest_value(manifest, key):
    values = [line.split("=", 1)[1] for line in manifest.splitlines() if line.startswith(f"{key}=")]
    if len(values) != 1:
        raise ValueError(f"SOURCE-MANIFEST missing or duplicates {key}")
    return values[0]


def check_source(root, repo, commit, version):
    manifest = (root / "SOURCE-MANIFEST.txt").read_text()
    if manifest_value(manifest, "source_commit") != commit:
        raise ValueError("SOURCE-MANIFEST source commit mismatch")
    if manifest_value(manifest, "cargo_workspace_version") != version:
        raise ValueError("SOURCE-MANIFEST version mismatch")
    if f'version = "{version}"' not in (root / "Cargo.toml").read_text():
        raise ValueError("archive Cargo version mismatch")
    if run(["git", "-C", str(repo), "rev-parse", f"{commit}^{{commit}}"], capture=True).strip() != commit:
        raise ValueError("local source repository lacks the exact release commit")
    names = run(["git", "-C", str(repo), "ls-tree", "-r", "--name-only", commit], capture=True).splitlines()
    with tempfile.TemporaryDirectory() as temporary:
        expected = Path(temporary)
        subprocess.run(["git", "-C", str(repo), "archive", commit], check=True, stdout=(expected / "tree.tar").open("wb"))
        with tarfile.open(expected / "tree.tar") as tar:
            tar.extractall(expected / "tree", filter="data")
        for name in names:
            actual, reference = root / name, expected / "tree" / name
            if not actual.is_file() or actual.read_bytes() != reference.read_bytes():
                raise ValueError(f"source tree mismatch: {name}")
    return names, manifest


def check_dry_run(text):
    records = [json.loads(line) for line in text.splitlines() if line.strip()]
    if len(records) != 4:
        raise ValueError("diagnose-v2 dry-run must emit four JSONL records")
    admitted, work, missing, terminal = records
    required_admission = {"command", "status", "scientific_status", "case", "case_sha256",
                          "family_identity", "probe_identity", "grids", "steps", "branch_profiles",
                          "force_grid", "workers", "tick_exponent", "clock_target_ticks",
                          "accepted_clocks", "probe_clocks", "memory_cap", "joint_storage_bytes"}
    if admitted.get("command") != "diagnose-v2" or admitted.get("status") != "admitted" or not required_admission <= admitted.keys():
        raise ValueError("invalid diagnose-v2 admission metadata")
    if work.get("type") != "work_preflight" or not {"probe_weighted_visits", "residual_provider_work", "binding_node_lookups"} <= work.keys():
        raise ValueError("invalid diagnose-v2 work preflight metadata")
    if not isinstance(missing.get("missing_channels"), list) or not missing["missing_channels"]:
        raise ValueError("invalid diagnose-v2 missing-channel metadata")
    if terminal != {"command": "diagnose-v2", "status": "dry_run", "driver_allocated": False,
                    "qualified_windows": 0, "pde_qualified": False}:
        raise ValueError("diagnose-v2 dry-run terminal metadata mismatch")
    return records


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("archive", type=Path)
    parser.add_argument("archive_sha256", type=Path)
    parser.add_argument("--source-repo", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--commit", default=COMMIT)
    parser.add_argument("--version", default=VERSION)
    parser.add_argument("--tag", default=TAG)
    parser.add_argument("--skip-cli", action="store_true", help="smoke source/checksum stages only")
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=False)
    sidecar = args.archive_sha256.read_text().splitlines()
    expected = [SHA.fullmatch(line) for line in sidecar]
    if len(expected) != 1 or not expected[0] or expected[0].group(2) != args.archive.name or digest(args.archive) != expected[0].group(1):
        raise ValueError("detached archive checksum mismatch")
    root = check_tar(args.archive, args.out / "extract")
    source_files, manifest = check_source(root, args.source_repo, args.commit, args.version)
    if manifest_value(manifest, "snapshot_tag") != args.tag:
        raise ValueError("SOURCE-MANIFEST tag mismatch")
    if manifest_value(manifest, "target") != "x86_64-unknown-linux-gnu":
        raise ValueError("SOURCE-MANIFEST target mismatch")
    if manifest_value(manifest, "scientific_status") != "diagnostic-only; unqualified":
        raise ValueError("SOURCE-MANIFEST scientific status mismatch")
    if root.name != args.archive.name.removesuffix(".tar.gz"):
        raise ValueError("archive root/name mismatch")
    sum_entries = check_sums(root, source_files)
    help_text = version_text = ""
    dry_json = []
    if not args.skip_cli:
        binary = root / "bin" / "nsbu"
        help_text = run([str(binary), "--help"], capture=True)
        version_text = run([str(binary), "--version"], capture=True)
        if args.version not in version_text:
            raise ValueError("binary version mismatch")
        dry = run([str(binary), "diagnose-v2", "--dry-run"], capture=True)
        dry_json = check_dry_run(dry)
    summary = {"tag": args.tag, "source_commit": args.commit, "version": args.version,
               "archive_sha256": digest(args.archive), "sha256sums_entries": sum_entries,
               "source_files_compared": len(source_files), "dry_run_jsonl": dry_json,
               "cli_verification": "skipped" if args.skip_cli else "passed"}
    (args.out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    (args.out / "help.txt").write_text(help_text)
    (args.out / "version.txt").write_text(version_text)
    (args.out / "SOURCE-MANIFEST.txt").write_text(manifest)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
