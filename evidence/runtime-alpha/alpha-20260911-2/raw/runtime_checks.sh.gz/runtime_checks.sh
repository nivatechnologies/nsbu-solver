#!/usr/bin/env bash
set -euo pipefail
binary="$1"
out="$2"
timeout 300s /usr/bin/time -v "$binary" v2 > "$out/cm.json" 2> "$out/cm.time"
timeout 300s /usr/bin/time -v "$binary" v2 --method ho > "$out/ho.json" 2> "$out/ho.time"
timeout 300s /usr/bin/time -v "$binary" v2 --method ho --checkpoint "$out/ho.chk" --checkpoint-after 16 > "$out/ho-saved.json" 2> "$out/ho-saved.time"
timeout 300s /usr/bin/time -v "$binary" resume-v2 --method ho --checkpoint "$out/ho.chk" > "$out/ho-resumed.json" 2> "$out/ho-resumed.time"
timeout 600s /usr/bin/time -v "$binary" diagnose-v2 > "$out/diagnose-full.jsonl" 2> "$out/diagnose-full.time"
