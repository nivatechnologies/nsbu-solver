NSBU Solver's first runtime alpha provides a standalone Rust library and Linux CLI for bounded Navier–Stokes diagnostics. It includes the exact `similarity-mms-v2` force, independently evolved trajectories from rest with CM and HO integrators, resource preflight, exact tick timing, transactional attempts, measured balances, and checkpoint/resume.

This is a usable **diagnostic runtime alpha**, with **zero accepted concentrating PDE windows**. Larger-grid convergence, full scientific provenance, and the concentrating experiment verifier remain incomplete. The analytical reference never replaces or resets the integrated state.

## Run the alpha

Download the Linux x86_64 GNU/glibc archive and its `.sha256` file. The binary is built and tested on Ubuntu 24.04; inspect `SOURCE-MANIFEST.txt` for its exact dynamic-library requirements. Other platforms require source builds and are not verified by this binary release.

```sh
sha256sum -c nsbu-solver-alpha-first-20260911-x86_64-unknown-linux-gnu.tar.gz.sha256
tar -xzf nsbu-solver-alpha-first-20260911-x86_64-unknown-linux-gnu.tar.gz
cd nsbu-solver-alpha-first-20260911-x86_64-unknown-linux-gnu
sha256sum -c SHA256SUMS
./bin/nsbu v2 --dry-run
./bin/nsbu v2
./bin/nsbu v2 --method ho --checkpoint run.chk --checkpoint-after 16
./bin/nsbu resume-v2 --method ho --checkpoint run.chk
```

The default diagnostic uses N4/M4 and reaches t = 1/256 in 32 committed steps. Imported checkpoints retain `external_unverified` origin. Same-build restart equivalence is tested; the format does not authenticate compiler or processor identity for cross-release/platform guarantees.

The archive includes the complete matching source tree, hidden build inputs, Apache-2.0 license and notices, documentation, immutable design artifacts, validation evidence, and source/binary checksums. The workspace crate version is `0.1.0-alpha.0`; the dated immutable snapshot tag identifies this distribution.

## Validation

- 434 Rust tests/allocation probes plus one compiled public Rustdoc example passed locally.
- Rust line coverage: 98.56%; branch coverage: 88.79%.
- Maximum cyclomatic complexity 21, cognitive complexity 18, Halstead difficulty 75.8956, file length 477, and CRAP 24.33594.
- Clean workspace packaging and CLI installation passed. Both methods match independent high-precision direct-DFT small-grid fixtures within 5e-13; interrupted/resumed state and ledgers match uninterrupted execution in the tested build.
- All 98 maintained Python/stub files match the retained 220-test local profile; 41 bootstrap tests and original mathematical verification were rerun. The full Python suite and all required Rust checks are also required in hosted CI for this exact release commit.

Source: [`63f9a145c8e3b0168e7f8896f0f92f3217cdf57f`](https://github.com/nivatechnologies/nsbu-solver/commit/63f9a145c8e3b0168e7f8896f0f92f3217cdf57f).

[Runtime guide](https://github.com/nivatechnologies/nsbu-solver/blob/63f9a145c8e3b0168e7f8896f0f92f3217cdf57f/docs/RUNTIME_ALPHA.md) · [Validation evidence](https://github.com/nivatechnologies/nsbu-solver/blob/63f9a145c8e3b0168e7f8896f0f92f3217cdf57f/evidence/runtime-alpha/README.md) · [Rust CI](https://github.com/nivatechnologies/nsbu-solver/actions/runs/34559085301) · [Python/repository CI](https://github.com/nivatechnologies/nsbu-solver/actions/runs/34559085317).

Daily prereleases are scheduled for 02:17 UTC when new source changes have passed the release gates. Correctness studies, the scientific verifier, and optimization continue toward a qualified and stable solver. Visualization follows solver validation.
