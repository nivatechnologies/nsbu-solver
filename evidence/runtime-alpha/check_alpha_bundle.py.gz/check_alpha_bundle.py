import json, os, subprocess, tempfile, yaml
from pathlib import Path
root=Path('/mnt/niva-array/nsbu-solver/work/runtime-alpha-development')
workflow=yaml.safe_load((root/'.github/workflows/alpha-release.yml').read_text())
script=next(step['run'] for step in workflow['jobs']['release']['steps'] if step['name']=='Assemble binary, notices, documentation and provenance')
script=script.replace('${{ github.repository }}','nivatechnologies/nsbu-solver').replace('target/x86_64-unknown-linux-gnu/release/nsbu',str(root/'target/release/nsbu'))
work=Path(tempfile.mkdtemp(prefix='runtime-alpha-bundle-',dir=root.parent))
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
env=dict(os.environ,SOURCE_SHA=sha,SNAPSHOT_TAG='alpha-first-20260911',PREVIOUS_TAG='',GITHUB_WORKSPACE=str(root),GITHUB_OUTPUT=str(work/'outputs'),GIT_DIR=subprocess.check_output(['git','rev-parse','--absolute-git-dir'],cwd=root,text=True).strip())
with (root.parent/'runtime-alpha-bundle-check.log').open('w') as log:
    subprocess.run(['bash','-euo','pipefail','-c',script],env=env,cwd=work,check=True,stdout=log,stderr=subprocess.STDOUT)
    folder=work/'nsbu-solver-alpha-first-20260911-x86_64-unknown-linux-gnu'
    subprocess.run(['sha256sum','-c',str(folder)+'.tar.gz.sha256'],cwd=work,check=True,stdout=log)
    subprocess.run([str(folder/'bin/nsbu'),'--version'],check=True,stdout=log)
    subprocess.run([str(folder/'bin/nsbu'),'v2','--dry-run'],check=True,stdout=log)
assert 'cargo_workspace_version=0.1.0-alpha.0\n' in (folder/'SOURCE-MANIFEST.txt').read_text()
result={'status':'passed','source_commit':sha,'bundle_directory':str(folder),'source_binary':'tested local release binary; hosted target build still required','internal_and_external_checksums':'passed','manifest':(folder/'SOURCE-MANIFEST.txt').read_text()}
(root.parent/'runtime-alpha-bundle-summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
