#!/usr/bin/env bash
set -euo pipefail
export PATH="$PATH:/mnt/niva-array/nsbu-solver/work/rust-tools/bin"
cargo fmt --all -- --check > ../v2-family-format-final.log 2>&1
rust-code-analysis-cli -p crates -m -O json > ../v2-family-metrics-final.json
cargo +nightly-2026-03-03 llvm-cov --package nsbu-benchmarks --test v2_family --test v2_family_allocation --example v2_refinement --branch --no-default-ignore-filename-regex --ignore-filename-regex '(/rustc/|/\.cargo/registry/|/\.rustup/toolchains/|/target/)' --json --output-path ../v2-family-focused-coverage.json > ../v2-family-focused-coverage.log 2>&1
/mnt/niva-array/nsbu-solver/.venv/bin/python - <<'PY'
import json
from pathlib import Path
paths=[*Path('crates/nsbu-benchmarks/src/v2_experiment').glob('*.rs'),*Path('crates/nsbu-benchmarks/tests').glob('v2_family*.rs'),Path('crates/nsbu-benchmarks/examples/v2_refinement.rs')]
files={str(p.resolve()) for p in paths}
metrics=[]
for line in Path('../v2-family-metrics-final.json').read_text().splitlines():
    data=json.loads(line)
    if str(Path(data['name']).resolve()) in files: metrics.append(line)
assert len(metrics)==8,len(metrics)
Path('../v2-family-focused-metrics.json').write_text('\n'.join(metrics)+'\n')
PY
/mnt/niva-array/nsbu-solver/.venv/bin/python quality/check_crap.py rust ../v2-family-focused-metrics.json ../v2-family-focused-coverage.json ../v2-family-focused-crap.json > ../v2-family-focused-crap.log 2>&1
RUSTDOCFLAGS='-D warnings' cargo doc --workspace --no-deps --locked > ../v2-family-rustdoc.log 2>&1
