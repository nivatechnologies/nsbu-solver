import datetime, gzip, hashlib, json, platform, re
from pathlib import Path
root = Path('/mnt/niva-array/nsbu-solver/work/p09-v2-family-development')
work = root.parent
out = root/'evidence/p09/v2-family'
out.mkdir(parents=True, exist_ok=True)
sha = lambda raw: hashlib.sha256(raw).hexdigest()
def write(name, value):
    (out/name).write_text(json.dumps(value, indent=2)+'\n')
source = {str(p.relative_to(root)): sha(p.read_bytes()) for folder in ('crates','reference','quality','tools','typings') for p in (root/folder).rglob('*') if p.suffix in ('.rs','.py','.pyi')}
rust = [p for p in source if p.endswith('.rs')]
python = [p for p in source if not p.endswith('.rs')]
previous = json.loads((root/'evidence/runtime-alpha/source-sha256.json').read_text())
assert len(rust)==340 and len(python)==98
assert all(source[p]==previous[p] for p in python)
new_paths = [p for p in rust if p not in previous]
assert len(new_paths)==8
changed = [p for p in previous if source[p]!=previous[p]]
assert changed==['crates/nsbu-benchmarks/src/lib.rs'],changed
metrics = [json.loads(line) for line in (work/'v2-family-metrics-final.json').read_text().splitlines()]
def walk(entry):
    yield entry
    for child in entry['spaces']: yield from walk(child)
spaces = [node for entry in metrics for node in walk(entry)]
functions = [node for node in spaces if node['kind']=='function']
maxima = {'cyclomatic': max(n['metrics']['cyclomatic']['sum'] for n in functions), 'cognitive':max(n['metrics']['cognitive']['sum'] for n in functions), 'halstead_function_and_file':max(n['metrics']['halstead']['difficulty'] or 0 for n in spaces), 'physical_file_lines':max(len((root/p).read_text().splitlines()) for p in rust)}
for name, cap in [('cyclomatic',22),('cognitive',22),('halstead_function_and_file',80),('physical_file_lines',500)]: assert maxima[name]<cap,(name,maxima[name])
coverage = json.loads((work/'v2-family-focused-coverage.json').read_text())['data'][0]
files = [f for f in coverage['files'] if str(Path(f['filename']).relative_to(root)) in new_paths]
assert len(files)==8
focus = {}
for key in ('lines','branches'):
    total=sum(f['summary'][key]['count'] for f in files)
    covered=sum(f['summary'][key]['covered'] for f in files)
    focus[key]={'count':total,'covered':covered,'percent':100*covered/total}
    assert focus[key]['percent']>=80
crap = json.loads((work/'v2-family-focused-crap.json').read_text())['maximum']
assert crap<25
lexical = [f'{p}:{i}:{line}' for p in rust for i,line in enumerate((root/p).read_text().splitlines(),1) if re.search(r'\b(Any|unknown)\b',line)]
escapes = [line for line in lexical if not line.split(':',2)[2].lstrip().startswith('//')]
assert not escapes,escapes
write('type-identifier-scan.json',{'lexical_matches':lexical,'code_matches':escapes,'scope':rust,'method':'CI lexical identifier rule; compiler and strict Clippy resolve concrete inferred types'})
raw=(work/'v2-family-focused-coverage.log').read_text()
assert sum(map(int,re.findall(r'test result: ok\. (\d+) passed',raw)))==7
assert 'steady_allocations=0' in raw
example=(work/'v2-family-example-release.log').read_text()
assert 'elapsed=128 ' in example and 'accepted_pde_windows=0' in example
write('source-sha256.json',source)
write('summary.json',{
 'package':'P09', 'increment':'independent exact-v2 refinement family',
 'status':'focused numerical and new-source quality gates passed; complete source-matched hosted gates pending',
 'generated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'parent_commit':'6fad3ca', 'source_inventory':'source-sha256.json',
 'rust_source_files':len(rust),'new_rust_source_files':new_paths,
 'focused_tests':{'harness':6,'example':1,'isolated_allocation_executables':1,'total':8},
 'focused_coverage':focus,'focused_crap_maximum':crap,'whole_workspace_static_maxima':maxima,
 'quality_scope':'Focused coverage and CRAP cover all eight added Rust source/test/example files. Complete existing-source coverage and CRAP are retained from the alpha and must rerun in hosted CI before daily publication. Whole current Rust source has fresh complexity/size/typing/lint measurements.',
 'unchanged_python':{'source_files':98,'retained_tests':220,'evidence':'../../runtime-alpha/publication/hosted-python.json'},
 'profile':{'retained_grids':[4,8,12],'force_grid':[12,12,12],'workers':0,'step_ticks':[64,32,16],'clock_exponent':-20,'target_ticks':8192,'endpoint_ticks':128,'sample_ticks':[0,64,128],'endpoint_rational':'1/8192','case_sha256':sha((root/'benchmarks/similarity-mms-v2.json').read_bytes()),'test_absolute_tolerances':[1e-5,1e-4],'test_relative_tolerances':[0,0],'example_relative_tolerances':[1e-5,1e-5],'advective_limit':0.3},
 'numerical_checks':[
  'Six private exact-v2 states evolve independently from rest with fixed force M across spatial refinements.',
  'All five actual endpoint pairs agree with an explicit signed-mode full-complex sum for L2/H1/curl/divergence common/new/full norms and means; tolerance 5e-14*(1+expected).',
  'Canonical versioned little-endian identity agrees with an independently assembled fixture and changes with all admitted settings and exact clock representations.',
  'Invalid profiles, byte caps, attempt-count overflow and time manifests refuse before allocation.',
  'A failed child retains its committed clock/coefficient words and charged work; repeat advance terminates without changes.',
  'The documented release example reaches every declared sample time and reports actual differences.'
 ],
 'resource_checks':{'construction_heap_bytes':19219520,'declared_storage_bytes':24190424,'admission_and_refusal_allocations':0,'steady_allocations_reallocations_deallocations':0,'identity_bytes':484,'integration_calls':480,'provider_work_units':174763008,'scalar_transforms':6696,'comparison_work_units':82752},
 'execution_profile':{'rust':'1.94.0','coverage_toolchain':'nightly-2026-03-03','cargo_llvm_cov':'0.9.1','rust_code_analysis':'0.0.25','host':platform.platform(),'cargo_lock_sha256':sha((root/'Cargo.lock').read_bytes()),'manifests':{p:sha((root/p).read_bytes()) for p in ['Cargo.toml','crates/nsbu-benchmarks/Cargo.toml','rust-toolchain.toml']},'test_opt_level':2,'test_debug_assertions':True,'test_overflow_checks':True},
 'solid_review':'Immutable aggregate admission, canonical identity, branch ownership and comparison sampling have separate responsibilities. Each branch reuses the released Run/PrescribedForce contracts. The independent Fourier-sum test deliberately retains separate indexing and accumulation. No analytical state can be assigned through the family API.',
 'informational_findings':'Mutation and duplication sweeps not rerun for this increment; historical reports retained. Strict Clippy permits only informational dead_code warnings from shared test helpers.',
 'limitations':[
  'This is a short startup test at 1/8192, not the first concentrating endpoint at 1/256.',
  'A preliminary longer/coarser startup profile stopped on its H1 local indicator; the retained positive test uses smaller steps, not relaxed tolerances.',
  'Full physical/local/reference/force/arithmetic/reconstruction/quadrature/provenance integration remains incomplete.',
  'Family hashes identify settings and clocks; they do not authenticate complete external scientific provenance.',
  'There is no cross-branch rollback; all existing committed progress and charged work remain on terminal failure.',
  'Caller-owned manifests and retained reports require a separate storage budget.'
 ],'accepted_pde_windows':0,'artifact_inventory':'artifact-sha256.json'})
artifacts={}
for name in ['focused-coverage.json','metrics-final.json','focused-metrics.json','focused-crap.json','focused-coverage.log','format-final.log','clippy-final.log','rustdoc.log','example-release.log']:
    raw=(work/('v2-family-'+name)).read_bytes(); data=gzip.compress(raw,mtime=0); filename=name+'.gz'
    (out/filename).write_bytes(data)
    artifacts[filename]={'bytes':len(data),'sha256':sha(data),'uncompressed_bytes':len(raw),'uncompressed_sha256':sha(raw)}
for name in ['check_v2_family_focused.sh','record_v2_family_evidence.py']:
    raw=(work/name).read_bytes(); data=gzip.compress(raw,mtime=0); filename=name+'.gz'; (out/filename).write_bytes(data)
    artifacts[filename]={'bytes':len(data),'sha256':sha(data),'uncompressed_bytes':len(raw),'uncompressed_sha256':sha(raw)}
write('artifact-sha256.json',artifacts)
print(json.dumps({'coverage':focus,'crap':crap,'maxima':maxima},indent=2))
