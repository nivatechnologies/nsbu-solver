#!/usr/bin/env bash
set -euo pipefail
export PATH="$PATH:/mnt/niva-array/nsbu-solver/work/rust-tools/bin"
cargo fmt --all -- --check
cargo clippy --workspace --all-targets --locked -- -D warnings -A dead_code
RUSTDOCFLAGS='-D warnings' cargo doc --workspace --no-deps --locked
cargo test -p nsbu-cli --test diagnose_v2_cli -- --nocapture
cargo test -p nsbu-benchmarks --test v2_startup_profile
cargo test -p nsbu-benchmarks --example v2_diagnostic_coordinator
cargo +nightly-2026-03-03 llvm-cov clean --workspace
cargo +nightly-2026-03-03 llvm-cov --package nsbu-cli --test diagnose_v2_cli --branch --no-report -- --nocapture
cargo +nightly-2026-03-03 llvm-cov --package nsbu-benchmarks --test v2_startup_profile --example v2_diagnostic_coordinator --branch --no-report
cargo +nightly-2026-03-03 llvm-cov report --branch --no-default-ignore-filename-regex --ignore-filename-regex '(/rustc/|/\.cargo/registry/|/\.rustup/toolchains/|/target/)' --json --output-path /tmp/v2-diagnose-cli-coverage.json
rust-code-analysis-cli -p crates -m -O json > /tmp/v2-diagnose-cli-metrics.json
python - <<'PY'
import json,re
rows=[json.loads(line) for line in open('/tmp/v2-diagnose-cli-metrics.json') if line.strip()]
pattern=re.compile(r'crates/nsbu-(benchmarks/examples/v2_diagnostic_coordinator|benchmarks/src/v2_experiment/diagnostic/profile|cli/src/diagnose_v2)\.rs$')
with open('/tmp/v2-diagnose-cli-focused-metrics.json','w') as target:
    for row in rows:
        if pattern.search(row['name']):
            target.write(json.dumps(row,separators=(',',':'))+'\n')
PY
/mnt/niva-array/nsbu-solver/.venv/bin/python quality/check_crap.py rust /tmp/v2-diagnose-cli-focused-metrics.json /tmp/v2-diagnose-cli-coverage.json /tmp/v2-diagnose-cli-crap.json
