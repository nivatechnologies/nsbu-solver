#!/usr/bin/env bash
set -euo pipefail
export PATH="$PATH:/mnt/niva-array/nsbu-solver/work/rust-tools/bin"
cargo fmt --all -- --check > ../v2-physical-format-final.log 2>&1
cargo clippy --workspace --all-targets --locked -- -D warnings -A dead_code > ../v2-physical-clippy-final.log 2>&1
rust-code-analysis-cli -p crates -m -O json > ../v2-physical-metrics.json
jq -se '[.. | objects | select(.kind? == "function") | .metrics.cyclomatic.sum] | max < 22' ../v2-physical-metrics.json
jq -se '[.. | objects | select(.kind? == "function") | .metrics.cognitive.sum] | max < 22' ../v2-physical-metrics.json
jq -se '[.. | objects | select(has("metrics")) | .metrics.halstead.difficulty | select(. != null)] | max < 80' ../v2-physical-metrics.json
# Retain the admission/identity tests for the changed plan file without rerunning its old trajectory study.
cargo +nightly-2026-03-03 llvm-cov --package nsbu-benchmarks --test v2_family --branch --no-report --no-default-ignore-filename-regex --ignore-filename-regex '(/rustc/|/\.cargo/registry/|/\.rustup/toolchains/|/target/)' -- --skip six_branches --skip stopped_branch > ../v2-physical-plan-coverage.log 2>&1
cargo +nightly-2026-03-03 llvm-cov --no-clean --package nsbu-benchmarks --test v2_physical_family --test v2_physical_allocation --example v2_refinement --branch --no-default-ignore-filename-regex --ignore-filename-regex '(/rustc/|/\.cargo/registry/|/\.rustup/toolchains/|/target/)' --json --output-path ../v2-physical-focused-coverage.json > ../v2-physical-focused-coverage.log 2>&1
/mnt/niva-array/nsbu-solver/.venv/bin/python - <<'PY'
import json
from pathlib import Path
paths=[*Path('crates/nsbu-benchmarks/src/v2_experiment/physical').rglob('*.rs'),*Path('crates/nsbu-benchmarks/tests').glob('v2_physical*.rs'),Path('crates/nsbu-benchmarks/examples/v2_refinement.rs'),Path('crates/nsbu-benchmarks/src/v2_experiment/plan.rs')]
files={str(p.resolve()) for p in paths};rows=[]
for line in Path('../v2-physical-metrics.json').read_text().splitlines():
 data=json.loads(line)
 if str(Path(data['name']).resolve()) in files:rows.append(line)
assert len(rows)==7,len(rows)
Path('../v2-physical-focused-metrics.json').write_text('\n'.join(rows)+'\n')
PY
/mnt/niva-array/nsbu-solver/.venv/bin/python quality/check_crap.py rust ../v2-physical-focused-metrics.json ../v2-physical-focused-coverage.json ../v2-physical-focused-crap.json > ../v2-physical-focused-crap.log 2>&1
RUSTDOCFLAGS='-D warnings' cargo doc --workspace --no-deps --locked > ../v2-physical-rustdoc.log 2>&1
