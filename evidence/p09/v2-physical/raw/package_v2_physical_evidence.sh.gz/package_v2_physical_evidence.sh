#!/usr/bin/env bash
set -euo pipefail
evidence=evidence/p09/v2-physical
mkdir -p "$evidence/raw"
for raw in ../v2-physical-*.log ../v2-physical-*.json; do
  cp "$raw" "$evidence/raw/"
  gzip -f "$evidence/raw/$(basename "$raw")"
done
cp ../check_v2_physical_focused.sh "$evidence/raw/"
gzip -f "$evidence/raw/check_v2_physical_focused.sh"
for archive in "$evidence"/raw/*.gz; do
  printf '%s  %s\n' "$(gzip -dc "$archive" | sha256sum | cut -d' ' -f1)" "${archive%.gz}" >> "$evidence/raw-sha256-uncompressed.txt"
done
