#!/usr/bin/env bash
set -euo pipefail
export PATH="$PATH:/mnt/niva-array/nsbu-solver/work/rust-tools/bin"
ignore='(/rustc/|/\.cargo/registry/|/\.rustup/toolchains/|/target/)'
cargo fmt --all -- --check
cargo clippy --workspace --all-targets --locked -- -D warnings -A dead_code
RUSTDOCFLAGS='-D warnings' cargo doc --workspace --no-deps --locked
rust-code-analysis-cli -p crates -m -O json > /tmp/v2-pressure-metrics.json
cargo +nightly-2026-03-03 llvm-cov clean --workspace
cargo +nightly-2026-03-03 llvm-cov --package nsbu-benchmarks --lib --branch \
  --no-report -- v2_experiment::pressure
cargo +nightly-2026-03-03 llvm-cov --no-clean --package nsbu-benchmarks \
  --test v2_pressure_family --branch --no-default-ignore-filename-regex \
  --ignore-filename-regex "$ignore" --json \
  --output-path /tmp/v2-pressure-coverage.json
cargo +nightly-2026-03-03 llvm-cov --no-clean --package nsbu-benchmarks \
  --test v2_pressure_allocation --branch --no-default-ignore-filename-regex \
  --ignore-filename-regex "$ignore" --json \
  --output-path /tmp/v2-pressure-coverage.json
cargo +nightly-2026-03-03 llvm-cov --no-clean --package nsbu-benchmarks \
  --test v2_physical_family --branch --no-default-ignore-filename-regex \
  --ignore-filename-regex "$ignore" --json \
  --output-path /tmp/v2-pressure-coverage.json -- \
  physical_admission_rejects_invalid_floors_layout_count_caps_and_overflow
jq -c 'select(.name | test("crates/nsbu-benchmarks/(src/v2_experiment/(pressure/|physical/plan.rs)|tests/v2_pressure)"))' \
  /tmp/v2-pressure-metrics.json > /tmp/v2-pressure-focused-metrics.json
/mnt/niva-array/nsbu-solver/.venv/bin/python quality/check_crap.py rust \
  /tmp/v2-pressure-focused-metrics.json /tmp/v2-pressure-coverage.json \
  /tmp/v2-pressure-focused-crap.json
