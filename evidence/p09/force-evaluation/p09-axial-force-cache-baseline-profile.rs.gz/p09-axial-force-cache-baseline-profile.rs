//! Measure bounded v2 force cost and complete coefficient identity; timing is informational.
use nsbu_benchmarks::provider::V2Force;
use nsbu_solver::{
    domain::{Domain, Layout, TickClock},
    integrators::forcing::PrescribedForce,
    Complex64,
};
use sha2::{Digest, Sha256};
fn main() {
    for n in [8, 12, 16] {
        let domain = Domain::new([n; 3], [1.0; 3], 1.0).unwrap();
        let sampled = Layout::new([3 * n / 2; 3]).unwrap();
        let limits = V2Force::preflight(domain, sampled).unwrap();
        let mut provider = V2Force::new(domain, sampled, limits.storage_bytes).unwrap();
        let mut output: [Vec<Complex64>; 3] =
            std::array::from_fn(|_| vec![Complex64::new(0.0, 0.0); domain.layout().half_len()]);
        for tick in [1, 4, 2, 1] {
            let clock = TickClock::restore(-10, 8, tick, 8 - tick).unwrap();
            let start = std::time::Instant::now();
            let report = provider
                .evaluate(clock, limits, output.each_mut().map(Vec::as_mut_slice))
                .unwrap();
            let elapsed = start.elapsed().as_secs_f64();
            let mut hash = Sha256::new();
            for component in &output {
                for v in component {
                    hash.update(v.re.to_bits().to_le_bytes());
                    hash.update(v.im.to_bits().to_le_bytes());
                }
            }
            println!("grid={n} samples={} tick={tick} seconds={elapsed:.9} roots={} work={} bytes={} sha256={:x}",3*n/2,provider.last_root_iterations(),report.work_units,limits.storage_bytes,hash.finalize());
        }
    }
}
