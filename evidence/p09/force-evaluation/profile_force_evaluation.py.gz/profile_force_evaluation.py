import hashlib,json,platform,subprocess
from pathlib import Path
w=Path('/mnt/niva-array/nsbu-solver/work')
base=w/'p09-force-baseline-source';new=w/'p09-axial-force-cache-development'
expected=json.loads((w/'p09-axial-force-cache-initial-profile.json').read_text())['comparisons']
reports=[]
def measure(root,role,repetition):
    raw=subprocess.check_output([str(root/'target/release/examples/force_cache_profile')],cwd=root)
    path=w/f'p09-force-evaluation-{role}-repeat-{repetition}.log';path.write_bytes(raw)
    rows=[dict(v.split('=',1) for v in line.split()) for line in raw.decode().splitlines() if line.startswith('grid=')]
    assert len(rows)==12
    for a,b in zip(rows,expected):
        assert (int(a['grid']),int(a['tick']),a['sha256'])==(b['grid'],b['tick'],b['coefficient_sha256'])
    return rows
for repetition in range(3):
    order=[('baseline',base),('combined',new)] if repetition%2==0 else [('combined',new),('baseline',base)]
    results={role:measure(root,role,repetition) for role,root in order}
    for before,after in zip(results['baseline'],results['combined']):
        assert before['sha256']==after['sha256']
        reports.append({'repetition':repetition,'execution_order':[role for role,_ in order],
            'grid':int(after['grid']),'sample_grid':int(after['samples']),'tick':int(after['tick']),
            'baseline_seconds':float(before['seconds']),'combined_seconds':float(after['seconds']),
            'speed_ratio':float(before['seconds'])/float(after['seconds']),
            'baseline_root_iterations':int(before['roots']),'combined_root_iterations':int(after['roots']),
            'baseline_work':int(before['work']),'combined_work':int(after['work']),
            'baseline_bytes':int(before['bytes']),'combined_bytes':int(after['bytes']),
            'coefficient_sha256':after['sha256']})
    print(f'Interleaved pair {repetition+1}/3: every complete coefficient hash preserved.',flush=True)
sourcepaths=['crates/nsbu-benchmarks/examples/force_cache_profile.rs','crates/nsbu-benchmarks/src/provider.rs','crates/nsbu-benchmarks/src/fields.rs','crates/nsbu-benchmarks/src/jet/mod.rs','crates/nsbu-benchmarks/src/jet/index.rs']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
result={'baseline_commit':'7b57fd109ca1150c5a43c5de8201d63ea81edd1d','baseline_export':'Git archive plus the identical maintained profiling driver; no baseline numerical edits',
    'rustc':subprocess.check_output(['rustc','--version'],cwd=new,text=True).strip(),
    'profile':'release; complete calls are timed, allocation/formatting/hashing excluded',
    'host':platform.platform(),'scope':'three interleaved pairs on small fixed grids; shared host, timings informational',
    'source_sha256':{role:{p:sha(root/p) for p in sourcepaths} for role,root in [('baseline',base),('combined',new)]},
    'combined_axial_sha256':sha(new/'crates/nsbu-benchmarks/src/fields/axial.rs'),
    'comparisons':reports}
(w/'p09-force-evaluation-interleaved-profile.json').write_text(json.dumps(result,indent=2)+'\n')
print('Measured speed ratio range:',min(r['speed_ratio'] for r in reports),max(r['speed_ratio'] for r in reports))
