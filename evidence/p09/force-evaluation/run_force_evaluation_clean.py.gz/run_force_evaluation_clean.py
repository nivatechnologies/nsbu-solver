import hashlib,json,re,subprocess
from pathlib import Path
r=Path('/mnt/niva-array/nsbu-solver/work/p09-axial-force-cache-development');w=r.parent;c=w/'p09-force-evaluation-clean-source'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources={str(p.relative_to(r)):sha(p) for folder in ('crates','reference','quality','tools','typings') for p in (r/folder).rglob('*') if p.suffix in ('.rs','.py','.pyi')}
assert len(sources)==404
for p,h in sources.items():assert sha(c/p)==h,p
with (w/'p09-force-evaluation-clean-tests.log').open('w') as log:
 for args in [['--lib','fields::axial::tests'],['--lib','jet::'],['--test','axial_force_cache','--test','provider','--test','algebra','--example','force_cache_profile'],['--test','allocation']]:
  subprocess.run(['cargo','test','-p','nsbu-benchmarks',*args],cwd=c,stdout=log,stderr=subprocess.STDOUT,check=True)
with (w/'p09-force-evaluation-clean-build.log').open('w') as log:
 subprocess.run(['cargo','build','--release','-p','nsbu-benchmarks','--example','force_cache_profile'],cwd=c,stdout=log,stderr=subprocess.STDOUT,check=True)
outputs={}
for name,args in [('preflight',['--dry-run']),('profile',[])]:
 raw=subprocess.check_output([str(c/'target/release/examples/force_cache_profile'),*args],cwd=c)
 (w/('p09-force-evaluation-clean-'+name+'.log')).write_bytes(raw)
 previous=(w/('p09-force-evaluation-'+name+'.log')).read_bytes()
 normalize=lambda data:re.sub(rb'seconds=[0-9.]+',b'seconds=TIMING',data)
 assert normalize(raw)==normalize(previous),name
 outputs[name]=hashlib.sha256(normalize(raw)).hexdigest()
proof={'export':'complete staged public Git index without metadata','sources':sources,
 'manifests':{p:sha(r/p) for p in ('Cargo.toml','Cargo.lock','crates/nsbu-benchmarks/Cargo.toml')},
 'tests':'16 focused harness tests plus the complete benchmark allocation executable',
 'public_output':'preflight byte-identical; every force hash, work count and storage value identical after removing only measured elapsed seconds',
 'normalized_output_sha256':outputs}
(w/'p09-force-evaluation-clean-source-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
print('404 maintained source hashes, 16 focused tests, allocation and complete numerical profile reproduce.')
