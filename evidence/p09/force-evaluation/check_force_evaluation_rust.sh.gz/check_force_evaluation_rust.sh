#!/usr/bin/env bash
set -euo pipefail
export PATH="$PATH:/mnt/niva-array/nsbu-solver/work/rust-tools/bin"
cargo fmt --all -- --check
cargo clippy --workspace --all-targets -- -D warnings -A dead_code > ../p09-force-evaluation-clippy.log 2>&1
rust-code-analysis-cli -p crates -m -O json > ../p09-force-evaluation-metrics.json
jq -se '[.. | objects | select(.kind? == "function") | .metrics.cyclomatic.sum] | length > 0 and max < 22' ../p09-force-evaluation-metrics.json
jq -se '[.. | objects | select(.kind? == "function") | .metrics.cognitive.sum] | max < 22' ../p09-force-evaluation-metrics.json
jq -se '[.. | objects | select(has("metrics")) | .metrics.halstead.difficulty | select(. != null)] | max < 80' ../p09-force-evaluation-metrics.json
cargo +nightly-2026-03-03 llvm-cov --workspace --all-targets --branch --no-default-ignore-filename-regex --ignore-filename-regex '(/rustc/|/\.cargo/registry/|/\.rustup/toolchains/|/target/)' --json --output-path ../p09-force-evaluation-coverage.json > ../p09-force-evaluation-full-rust-tests.log 2>&1
/mnt/niva-array/nsbu-solver/.venv/bin/python quality/check_crap.py rust ../p09-force-evaluation-metrics.json ../p09-force-evaluation-coverage.json ../p09-force-evaluation-rust-crap.json
jq -e '.data[0].totals | .lines.percent >= 80 and .branches.percent >= 80' ../p09-force-evaluation-coverage.json
