#!/usr/bin/env bash
set -euo pipefail
export PATH="$PATH:/mnt/niva-array/nsbu-solver/work/rust-tools/bin"
cargo fmt --all -- --check
cargo clippy --workspace --all-targets --locked -- -D warnings -A dead_code
RUSTDOCFLAGS='-D warnings' cargo doc --workspace --no-deps --locked
rust-code-analysis-cli -p crates -m -O json > /tmp/v2-reconstruction-metrics.json
cargo +nightly-2026-03-03 llvm-cov clean --workspace
cargo +nightly-2026-03-03 llvm-cov --package nsbu-benchmarks --lib --branch --no-report -- smooth_observer::reconstruction::tests
for test_name in v2_reconstructed_run v2_reconstructed_run_allocation reconstruction_observer reconstruction_archive owned_reconstruction integrated_derivatives integrated_physical offstage_residual probe_family reconstructed_owner_archive reconstructed_replay; do
  cargo +nightly-2026-03-03 llvm-cov --package nsbu-benchmarks --test "$test_name" --branch --no-report
done
cargo +nightly-2026-03-03 llvm-cov report --branch --json --output-path /tmp/v2-reconstruction-coverage.json
jq -c 'select(.name | test("crates/nsbu-benchmarks/src/(smooth_observer/(reconstruction.rs|v2_reconstruction.rs)|v2_run/reconstructed.rs)$"))' /tmp/v2-reconstruction-metrics.json > /tmp/v2-reconstruction-focused-metrics.json
/mnt/niva-array/nsbu-solver/.venv/bin/python quality/check_crap.py rust /tmp/v2-reconstruction-focused-metrics.json /tmp/v2-reconstruction-coverage.json /tmp/v2-reconstruction-focused-crap.json
