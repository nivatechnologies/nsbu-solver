set -e
cd /mnt/niva-array/nsbu-solver/work/p09-reduction-arithmetic-development
QBIN=/mnt/niva-array/nsbu-solver/.venv/bin
mkdir -p work
"$QBIN/basedpyright" --venvpath /mnt/niva-array/nsbu-solver > ../p09-reduction-python-typing.log
"$QBIN/radon" cc -j -s quality reference tools > ../p09-reduction-python-cyclomatic.json
jq -e '[.. | objects | select(has("complexity") and .type != "class") | .complexity] | max < 22' ../p09-reduction-python-cyclomatic.json
"$QBIN/radon" hal -j -f quality reference tools > ../p09-reduction-python-halstead.json
jq -e '[.. | objects | select(has("difficulty")) | .difficulty] | max < 80' ../p09-reduction-python-halstead.json
"$QBIN/complexipy" quality reference tools --max-complexity-allowed 21 > ../p09-reduction-python-cognitive.log
"$QBIN/coverage" erase
"$QBIN/coverage" run -m pytest -q > ../p09-reduction-python-full-tests.log 2>&1
"$QBIN/coverage" combine > ../p09-reduction-python-coverage-combine.log
"$QBIN/coverage" json -o ../p09-reduction-python-coverage.json > ../p09-reduction-python-coverage-export.log
"$QBIN/python" quality/check_crap.py python ../p09-reduction-python-cyclomatic.json ../p09-reduction-python-coverage.json ../p09-reduction-python-crap.json
jq -e '.totals | .num_statements > 0 and .num_branches > 0 and (.covered_lines / .num_statements) >= 0.8 and (.covered_branches / .num_branches) >= 0.8' ../p09-reduction-python-coverage.json
