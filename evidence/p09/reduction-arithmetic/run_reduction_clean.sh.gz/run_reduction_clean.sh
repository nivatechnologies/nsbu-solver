set -euo pipefail
QBIN=/mnt/niva-array/nsbu-solver/.venv/bin
"$QBIN/python" -m pytest reference/tests/test_reduction_input.py reference/tests/test_reduction_oracle.py reference/tests/test_reduction_study.py -q > ../p09-reduction-clean-python-tests.log 2>&1
cargo test -p nsbu-benchmarks --example reduction_audit --test reduction_allocation > ../p09-reduction-clean-rust-tests.log 2>&1
mkdir -p work
cargo run --release -p nsbu-benchmarks --example reduction_audit -- crates/nsbu-benchmarks/data/reduction-n4.bin work/magnitudes-n4.bin > ../p09-reduction-clean-n4-rust.log 2> ../p09-reduction-clean-build.log
cmp work/magnitudes-n4.bin fixtures/reference/reduction-n4-magnitudes.bin
"$QBIN/python" - <<'PY'
import gzip
from pathlib import Path
from reference.reduction_audit.input import prepare
for n in (4,12):
 for method in ('cm','ho'):
  p=Path(f'work/derived-n{n}-{method}.json');p.write_bytes(gzip.decompress(Path(f'evidence/p09/derived-arithmetic/inputs/derived-n{n}-{method}.json.gz').read_bytes()))
 data=prepare(Path(f'work/derived-n{n}-cm.json'),Path(f'work/derived-n{n}-ho.json'),n)
 original=Path('crates/nsbu-benchmarks/data/reduction-n4.bin') if n==4 else Path('../p09-reduction-inputs/input-n12.bin')
 assert data==original.read_bytes();Path(f'work/input-n{n}.bin').write_bytes(data)
PY
cargo run --release -p nsbu-benchmarks --example reduction_audit -- work/input-n12.bin work/magnitudes-n12.bin > ../p09-reduction-clean-n12-rust.log 2>> ../p09-reduction-clean-build.log
cmp work/magnitudes-n12.bin ../p09-reduction-inputs/magnitudes-n12.bin
for n in 4 12; do
 "$QBIN/python" -m reference.verify_reductions --n "$n" --input "work/input-n$n.bin" --magnitudes "work/magnitudes-n$n.bin" > "../p09-reduction-clean-study-n$n.json"
 cmp "../p09-reduction-clean-study-n$n.json" "../p09-reduction-study-n$n.json"
done
