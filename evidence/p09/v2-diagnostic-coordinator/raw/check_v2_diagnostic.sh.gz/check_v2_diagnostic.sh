#!/usr/bin/env bash
set -euo pipefail
export PATH="$PATH:/mnt/niva-array/nsbu-solver/work/rust-tools/bin"
cargo fmt --all -- --check
cargo clippy --workspace --all-targets --locked -- -D warnings -A dead_code
RUSTDOCFLAGS='-D warnings' cargo doc --workspace --no-deps --locked
cargo test -p nsbu-benchmarks --test v2_diagnostic_coordinator -- --nocapture
cargo test -p nsbu-benchmarks --test v2_diagnostic_coordinator_allocation -- --nocapture
cargo run -p nsbu-benchmarks --example v2_diagnostic_coordinator --release -- --dry-run
cargo run -p nsbu-benchmarks --example v2_diagnostic_coordinator --release
rust-code-analysis-cli -p crates -m -O json > /tmp/v2-diagnostic-metrics.json
python - <<'PY'
import json,re
rows=[json.loads(line) for line in open('/tmp/v2-diagnostic-metrics.json') if line.strip()]
pattern=re.compile(r'crates/nsbu-benchmarks/src/v2_experiment/diagnostic/(mod|plan|report)\.rs$')
with open('/tmp/v2-diagnostic-focused-metrics.json','w') as target:
    for row in rows:
        if pattern.search(row['name']):
            target.write(json.dumps(row,separators=(',',':'))+'\n')
PY
cargo +nightly-2026-03-03 llvm-cov clean --workspace
cargo +nightly-2026-03-03 llvm-cov --package nsbu-benchmarks --test v2_diagnostic_coordinator --branch --no-report
cargo +nightly-2026-03-03 llvm-cov report --branch --json --output-path /tmp/v2-diagnostic-coverage.json
/mnt/niva-array/nsbu-solver/.venv/bin/python quality/check_crap.py rust /tmp/v2-diagnostic-focused-metrics.json /tmp/v2-diagnostic-coverage.json /tmp/v2-diagnostic-crap.json
