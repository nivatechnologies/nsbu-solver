#!/usr/bin/env bash
set -euo pipefail
export PATH="$PATH:/mnt/niva-array/nsbu-solver/work/rust-tools/bin"
cargo fmt --all -- --check
cargo clippy --workspace --all-targets --locked -- -D warnings -A dead_code
RUSTDOCFLAGS='-D warnings' cargo doc --workspace --no-deps --locked
rust-code-analysis-cli -p crates -m -O json > /tmp/v2-residuals-metrics.json
jq -c 'select(.name | test("crates/nsbu-benchmarks/src/v2_experiment/probes/residuals/(mod|plan|report|workspace).rs$"))' /tmp/v2-residuals-metrics.json > /tmp/v2-residuals-focused-metrics.json
jq -c 'select(.name | test("crates/nsbu-benchmarks/(src/v2_experiment/probes/residuals/(mod|plan|report|workspace)|tests/v2_(residual_family|residual_family_allocation|probe_family)).rs$"))' /tmp/v2-residuals-metrics.json > /tmp/v2-residuals-changed-metrics.json
cargo +nightly-2026-03-03 llvm-cov clean --workspace
cargo +nightly-2026-03-03 llvm-cov --package nsbu-benchmarks --test v2_residual_family --test v2_residual_family_allocation --branch --no-report
cargo +nightly-2026-03-03 llvm-cov --package nsbu-benchmarks --lib --branch --no-report -- v2_experiment::probes::residuals::workspace::tests::zero_allowance_small_cap_wrong_domain_and_exhaustion_are_refused
cargo +nightly-2026-03-03 llvm-cov report --branch --json --output-path /tmp/v2-residuals-coverage.json
/mnt/niva-array/nsbu-solver/.venv/bin/python quality/check_crap.py rust /tmp/v2-residuals-focused-metrics.json /tmp/v2-residuals-coverage.json /tmp/v2-residuals-focused-crap.json
