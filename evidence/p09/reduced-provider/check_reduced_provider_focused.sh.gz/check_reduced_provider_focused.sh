#!/usr/bin/env bash
set -euo pipefail
export PATH="$PATH:/mnt/niva-array/nsbu-solver/work/rust-tools/bin"
cargo fmt --all -- --check > ../reduced-provider-format.log 2>&1
cargo clippy --workspace --all-targets --locked -- -D warnings -A dead_code > ../reduced-provider-clippy-final.log 2>&1
rust-code-analysis-cli -p crates -m -O json > ../reduced-provider-metrics.json
jq -se '[.. | objects | select(.kind? == "function") | .metrics.cyclomatic.sum] | max < 22' ../reduced-provider-metrics.json
jq -se '[.. | objects | select(.kind? == "function") | .metrics.cognitive.sum] | max < 22' ../reduced-provider-metrics.json
jq -se '[.. | objects | select(has("metrics")) | .metrics.halstead.difficulty | select(. != null)] | max < 80' ../reduced-provider-metrics.json
cargo +nightly-2026-03-03 llvm-cov --package nsbu-benchmarks --lib --no-report --branch --no-default-ignore-filename-regex --ignore-filename-regex '(/rustc/|/\.cargo/registry/|/\.rustup/toolchains/|/target/)' -- reduced_force > ../reduced-provider-unit-coverage.log 2>&1
cargo +nightly-2026-03-03 llvm-cov --no-clean --package nsbu-benchmarks --test reduced_provider --test reduced_provider_allocation --test reduced_force --test reduced_force_allocation --example reduced_provider_profile --branch --no-default-ignore-filename-regex --ignore-filename-regex '(/rustc/|/\.cargo/registry/|/\.rustup/toolchains/|/target/)' --json --output-path ../reduced-provider-focused-coverage.json > ../reduced-provider-focused-coverage.log 2>&1
/mnt/niva-array/nsbu-solver/.venv/bin/python - <<'PY'
import json
from pathlib import Path
paths=[Path('crates/nsbu-benchmarks/src/provider/reduced.rs'),Path('crates/nsbu-benchmarks/src/reduced_force/axial.rs'),Path('crates/nsbu-benchmarks/src/reduced_force/axial/tests.rs'),Path('crates/nsbu-benchmarks/src/reduced_force/mod.rs'),*Path('crates/nsbu-benchmarks/tests').glob('reduced_provider*.rs'),Path('crates/nsbu-benchmarks/examples/reduced_provider_profile.rs')]
files={str(p.resolve()) for p in paths}; rows=[]
for line in Path('../reduced-provider-metrics.json').read_text().splitlines():
 data=json.loads(line)
 if str(Path(data['name']).resolve()) in files:rows.append(line)
assert len(rows)==8,len(rows)
Path('../reduced-provider-focused-metrics.json').write_text('\n'.join(rows)+'\n')
PY
/mnt/niva-array/nsbu-solver/.venv/bin/python quality/check_crap.py rust ../reduced-provider-focused-metrics.json ../reduced-provider-focused-coverage.json ../reduced-provider-focused-crap.json > ../reduced-provider-focused-crap.log 2>&1
RUSTDOCFLAGS='-D warnings' cargo doc --workspace --no-deps --locked > ../reduced-provider-rustdoc.log 2>&1
