import datetime
import gzip
import hashlib
import json
import platform
import re
import statistics
from pathlib import Path

root = Path('/mnt/niva-array/nsbu-solver/work/p09-reduced-provider-development')
work = root.parent
out = root / 'evidence/p09/reduced-provider'
out.mkdir(parents=True, exist_ok=True)
sha = lambda data: hashlib.sha256(data).hexdigest()

def write(name, value):
    (out / name).write_text(json.dumps(value, indent=2) + '\n')

def read(name):
    return json.loads((work / ('reduced-provider-' + name)).read_text())

sources = {str(p.relative_to(root)): sha(p.read_bytes())
           for folder in ('crates', 'reference', 'quality', 'tools', 'typings')
           for p in (root / folder).rglob('*') if p.suffix in ('.rs', '.py', '.pyi')}
previous = json.loads((root / 'evidence/p09/reduced-force/source-sha256.json').read_text())
added = sorted(set(sources) - set(previous))
changed = sorted(p for p in previous if sources[p] != previous[p])
assert len(added) == 7, added
assert changed == ['crates/nsbu-benchmarks/src/provider.rs', 'crates/nsbu-benchmarks/src/reduced_force/mod.rs'], changed
rust = [p for p in sources if p.endswith('.rs')]
python = [p for p in sources if not p.endswith('.rs')]
assert len(python) == 98 and all(sources[p] == previous[p] for p in python)
focus_paths = added + ['crates/nsbu-benchmarks/src/reduced_force/mod.rs']

def walk(node):
    yield node
    for child in node['spaces']:
        yield from walk(child)

nodes = [node for line in (work / 'reduced-provider-metrics.json').read_text().splitlines()
         for node in walk(json.loads(line))]
functions = [n for n in nodes if n['kind'] == 'function']
maxima = {
    'cyclomatic': max(n['metrics']['cyclomatic']['sum'] for n in functions),
    'cognitive': max(n['metrics']['cognitive']['sum'] for n in functions),
    'halstead_function_and_file': max(n['metrics']['halstead']['difficulty'] or 0 for n in nodes),
    'physical_file_lines': max(len((root / p).read_text().splitlines()) for p in rust),
}
for name, cap in [('cyclomatic', 22), ('cognitive', 22), ('halstead_function_and_file', 80), ('physical_file_lines', 500)]:
    assert maxima[name] < cap
files = [f for f in read('focused-coverage.json')['data'][0]['files']
         if str(Path(f['filename']).relative_to(root)) in focus_paths]
assert len(files) == 8
coverage = {}
for key in ('lines', 'branches'):
    count = sum(f['summary'][key]['count'] for f in files)
    covered = sum(f['summary'][key]['covered'] for f in files)
    coverage[key] = {'count': count, 'covered': covered, 'percent': 100 * covered / count}
    assert coverage[key]['percent'] >= 80
crap = read('focused-crap.json')['maximum']
assert crap < 25
lexical = [f'{p}:{i}:{line}' for p in rust
           for i, line in enumerate((root / p).read_text().splitlines(), 1)
           if re.search(r'\b(Any|unknown)\b', line)]
escapes = [line for line in lexical if not line.split(':', 2)[2].lstrip().startswith('//')]
assert not escapes, escapes
write('type-identifier-scan.json', {'lexical_matches': lexical, 'code_matches': escapes, 'scope': rust,
      'method': 'CI lexical identifier rule; compiler and strict Clippy resolve concrete inferred types'})
unit_log = (work / 'reduced-provider-unit-coverage.log').read_text()
integration_log = (work / 'reduced-provider-focused-coverage.log').read_text()
assert sum(map(int, re.findall(r'test result: ok\. (\d+) passed', unit_log))) == 8
assert sum(map(int, re.findall(r'test result: ok\. (\d+) passed', integration_log))) == 7
assert 'constructor_heap_bytes=30560 declared_bytes=32088 steady_allocations=0' in integration_log
profile = (work / 'reduced-provider-profile-release.log').read_text()
rows = re.findall(r'provider=(\w+) tick=(\d+) seconds=([0-9.]+) work=(\d+) transforms=(\d+) sha256=([0-9a-f]+)', profile)
assert len(rows) == 8 and 'accepted_pde_windows=0' in profile
assert [r[0] for r in rows] == ['cartesian', 'reduced'] * 4
assert all(rows[i][3:5] == rows[i + 1][3:5] for i in range(0, 8, 2))
assert rows[0][3:] == rows[6][3:] and rows[1][3:] == rows[7][3:]
ratios = [float(rows[i][2]) / float(rows[i + 1][2]) for i in range(0, 8, 2)]
errors = list(map(float, re.findall(r'maximum_scaled_coefficient_difference=([^\s]+)', profile)))
assert len(errors) == 4 and max(errors) < 5e-12
bootstrap = (work / 'reduced-provider-bootstrap.log').read_text()
assert 'Ran 41 tests' in bootstrap and bootstrap.rstrip().endswith('OK')
assert read('repository.json')['status'] == 'passed'
assert json.loads((root / 'work/design-checks.json').read_text())['bootstrap_execution']['matches_preserved_report']
write('source-sha256.json', sources)
write('summary.json', {
    'package': 'P09', 'increment': 'optional reduced-coordinate sampled exact-v2 force provider',
    'status': 'focused numerical/new-source quality and whole-workspace static/lint gates passed; complete source-matched hosted gates pending',
    'generated_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'parent_commit': '82c079670287b6db36737ec0f56cc3f3a69ee672',
    'source_inventory': 'source-sha256.json', 'rust_source_files': len(rust),
    'added_rust_source_files': added, 'changed_rust_source_files': changed,
    'focused_tests': {'library_unit_tests': 8, 'new_cache_unit_tests': 4,
                      'integration_tests': 6, 'new_provider_integration_tests': 3,
                      'example_tests': 1, 'isolated_allocation_probes': 2, 'total_executed': 17},
    'focused_coverage': coverage, 'focused_crap_maximum': crap,
    'whole_workspace_static_maxima': maxima,
    'quality_scope': 'Focused coverage/CRAP includes all seven added files and the changed reduced pointwise evaluator. The only other changed Rust file exports the provider module. All current Rust has fresh static/lint/size/typing measurements. Full current-source CI remains required before daily publication.',
    'initial_quality_failure': {'function': 'reduced_provider_profile::profile', 'crap': 27.890625,
                               'resolution': 'Separate complete resource admission from execution; unchanged numerical threshold and test contract.'},
    'unchanged_python': {'files': 98, 'retained_tests': 220},
    'numerical_checks': [
        'Every retained unprojected coefficient on (N4,M4), (N4,M6/8/12), (N8,M8/12/12) agrees with independent uncached direct complex DFT and the original Cartesian provider at nonmonotone ticks [1,4,2,1,0].',
        'The independent 80/120-digit N4 force fixture has all 18 rows checked at 5e-12 scaled L1 tolerance; a longitudinal raw-force mode is preserved.',
        'Axial cached and uncached reduced outputs including all momentum terms/residuals are bit-identical on tested planes and exact times; missing, stale or wrong-plane roots are refused.',
        'Different exact remaining times with equal rounded elapsed time do not alias the cache; all four time words are bound.',
        'Actual charged work equals sample count plus bounded per-plane root iterations; all requests report three transforms.',
        'Existing pointwise 84 exact-word fixtures and allocation tests remain passing.',
        'Malformed domains, dimensions, aggregate overflow, caps, output lengths and clocks refuse; tested validation failures preserve caller output and last-success diagnostics.'
    ],
    'scaled_coefficient_discrepancy_maxima': {'independent_direct_dft': 5.0997450932777024e-14,
                                            'original_cartesian_provider': 6.700812744181618e-14,
                                            'threshold': 5e-12, 'scale': 'complex L1 difference / (1 + reference complex L1)'},
    'resource_checks': {'allocation_test_retained': [4,4,4], 'allocation_test_sampled': [6,8,12],
                        'construction_heap_bytes': 30560, 'declared_bytes': 32088,
                        'admission_allocations': 0, 'steady_allocations_reallocations_deallocations': 0,
                        'completed_requests': 5, 'refused_requests': 3},
    'performance': {'scope': 'Full serial provider requests, including axial cache, sample construction, FFT and retained transfer; no PDE integration.',
                    'retained': [16,16,16], 'sampled': [24,24,24], 'ticks': [1,4,2,1],
                    'clock_exponent': -10, 'target_ticks': 8, 'requests_per_provider': 4,
                    'joint_storage_bytes': 9815792, 'stack_allowance_bytes': 8388608,
                    'stack_high_water_measured': False, 'profile_metadata_allowance_bytes': 16384,
                    'per_clock_speed_ratios': ratios, 'median_speed_ratio': statistics.median(ratios),
                    'maximum_scaled_coefficient_difference': max(errors),
                    'timing_limit': 'One sequential, alternating provider profile on a shared host; not a trajectory benchmark or cross-machine guarantee.'},
    'execution_profile': {'rust': '1.94.0', 'coverage_toolchain': 'nightly-2026-03-03',
                          'cargo_llvm_cov': '0.9.1', 'rust_code_analysis': '0.0.25',
                          'host': platform.platform(), 'case_sha256': sha((root/'benchmarks/similarity-mms-v2.json').read_bytes()),
                          'cargo_lock_sha256': sha((root/'Cargo.lock').read_bytes()),
                          'manifest_sha256': {p:sha((root/p).read_bytes()) for p in ['Cargo.toml','crates/nsbu-benchmarks/Cargo.toml','rust-toolchain.toml']},
                          'test_opt_level': 2, 'test_debug_assertions': True, 'test_overflow_checks': True},
    'solid_review': 'Public provider implements the existing PrescribedForce contract; resource admission, exact axial root binding, pointwise algebra, sampling and transforms remain separate responsibilities. Direct-DFT and high-precision oracles retain independent arithmetic. Released runtime force selection is unchanged.',
    'informational_findings': 'Mutation/duplication sweeps not rerun; historical results retained. Strict Clippy permits informational dead_code warnings from shared test helpers.',
    'limitations': ['Reduced arithmetic changes floating-point words; this is an optional explicit provider, not the default runtime implementation.',
                    'Run/ForceSettings/CLI/checkpoint arithmetic identity and integrated-trajectory checks remain before runtime adoption.',
                    'No force gradients or universal force error enclosure are provided.',
                    'Sampling/validation failures preserve outputs, but an exceptional later transform failure can leave partially written scratch outputs; outer numerical transactions still govern state commits.',
                    'P08/P09/P10 remain incomplete; no force-grid or concentrating PDE window is qualified.'],
    'bootstrap': {'repository_links_and_frozen_inputs': 'passed', 'guard_tests': 41, 'original_mathematical_verification': 'passed'},
    'accepted_pde_windows': 0, 'artifact_inventory': 'artifact-sha256.json'
})
artifacts = {}
for name in ['format.log', 'clippy-final.log', 'metrics.json', 'focused-metrics.json',
             'focused-coverage.json', 'focused-coverage.log', 'unit-coverage.log',
             'focused-crap.json', 'focused-crap-initial-failure.json', 'rustdoc.log',
             'integration-tests.log', 'allocation.log', 'cache-tests.log',
             'profile-preflight.log', 'profile-release.log', 'repository.json', 'bootstrap.log', 'design.log']:
    raw = (work / ('reduced-provider-' + name)).read_bytes()
    data = gzip.compress(raw, mtime=0)
    filename = name + '.gz'
    (out / filename).write_bytes(data)
    artifacts[filename] = {'bytes': len(data), 'sha256': sha(data), 'uncompressed_bytes': len(raw), 'uncompressed_sha256': sha(raw)}
for name in ['check_reduced_provider_focused.sh', 'record_reduced_provider_evidence.py']:
    raw = (work / name).read_bytes()
    data = gzip.compress(raw, mtime=0)
    (out / (name + '.gz')).write_bytes(data)
    artifacts[name + '.gz'] = {'bytes': len(data), 'sha256': sha(data), 'uncompressed_bytes': len(raw), 'uncompressed_sha256': sha(raw)}
write('artifact-sha256.json', artifacts)
print(json.dumps({'coverage': coverage, 'crap': crap, 'maxima': maxima, 'speed_ratios': ratios, 'median_speed_ratio': statistics.median(ratios)}, indent=2))
