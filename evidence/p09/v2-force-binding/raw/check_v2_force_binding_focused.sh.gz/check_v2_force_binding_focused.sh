#!/usr/bin/env bash
set -euo pipefail
export PATH="$PATH:/mnt/niva-array/nsbu-solver/work/rust-tools/bin"
cargo test -p nsbu-benchmarks --test v2_force_binding --locked -- --nocapture
cargo test -p nsbu-benchmarks --test v2_force_binding_allocation --locked -- --nocapture
cargo +nightly-2026-03-03 llvm-cov clean --workspace
cargo +nightly-2026-03-03 llvm-cov --package nsbu-benchmarks --test v2_force_binding --test v2_force_binding_allocation --branch --no-report
cargo +nightly-2026-03-03 llvm-cov --package nsbu-benchmarks --lib --branch --no-report -- v2_force_experiment::binding::tests::one_word_corruption_and_length_change_fail_bitwise_binding
cargo +nightly-2026-03-03 llvm-cov report --branch --no-default-ignore-filename-regex --ignore-filename-regex '(/rustc/|/\.cargo/registry/|/\.rustup/toolchains/|/target/)' --json --output-path focused-coverage.json
rust-code-analysis-cli -p crates -m -O json > all-source-metrics.json
# Retain all functions in new files and only the changed require_sample functions
# in pre-existing plan files before running quality/check_crap.py.
RUSTDOCFLAGS='-D warnings' cargo doc --workspace --no-deps --locked
cargo clippy -p nsbu-benchmarks --lib --test v2_force_binding --test v2_force_binding_allocation --locked -- -D warnings -A dead_code
cargo fmt --all -- --check
