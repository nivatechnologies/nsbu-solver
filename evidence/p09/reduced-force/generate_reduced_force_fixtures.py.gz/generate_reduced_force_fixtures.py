"""Bounded pointwise fixture study using the existing independent Cartesian mpmath evaluator."""
import hashlib,json,math,resource,sys,time
resource.setrlimit(resource.RLIMIT_AS,(256*1024*1024,256*1024*1024))
from pathlib import Path
r=Path('/mnt/niva-array/nsbu-solver/work/p09-reduced-force-development');sys.path.insert(0,str(r))
from mpmath import mp
from reference.evaluator import evaluate
w=r.parent
points=[(0.,0.,0.),(0.,0.,.125),(0.,0.,-.125),(2.**-20,-2.**-20,.125),(.03125,-.015625,.0625),(.125,.125,-.125),(.25,0.,.125),(.35,0.,.05),(.125,.25,.25),(.3,0.,0.),(math.nextafter(.3,0.),0.,0.),(math.nextafter(.42,0.),0.,0.)]
target=1<<63;ticks=[0,1,1<<59,1<<61,1<<62,target-(1<<30),target-1]
assert len(points)*len(ticks)==84
plan={'samples':84,'precisions':[80,120],'maximum_scalar_root_iterations_per_sample':2048,'maximum_force_evaluations':168,'process_address_space_cap_bytes':256*1024*1024,'scope':'Bounded pointwise existing Cartesian reference; no grid or trajectory allocation','quantum_exponent':-70,'target_ticks':target,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(w/'p09-reduced-force-fixture-preflight.json').write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps(plan),flush=True)
rows=[];studies=[];started=time.monotonic()
for tick in ticks:
 for point in points:
  versions=[]
  for precision in [80,120]:
   with mp.workdps(precision):
    exact=[mp.mpf(a)/b for a,b in (x.as_integer_ratio() for x in point)]
    result=evaluate(*exact,mp.mpf(tick)/(1<<70))
    values=[*result.velocity,result.pressure_raw,*result.force,*[x for row in result.momentum_terms for x in row]]
    versions.append(tuple(values))
  with mp.workdps(120):
   maximum=max(abs(a-b)/(1+abs(b)) for a,b in zip(*versions))
   assert maximum<mp.mpf('1e-50'),(tick,point,maximum)
   coordinates=[str(a)+'/'+str(b) for a,b in (x.as_integer_ratio() for x in point)]
   high=[mp.nstr(v,120) for v in versions[1]]
   rows.append('\t'.join([str(tick),*coordinates,*high]))
   studies.append({'tick':str(tick),'coordinates':coordinates,'precision_scaled_change':mp.nstr(maximum,20)})
 print('completed tick',tick,flush=True)
p=r/'crates/nsbu-benchmarks/tests/fixtures/reduced-force-words.tsv';p.write_text('\n'.join(rows)+'\n')
report={'status':'passed','plan':plan,'samples':studies,'fixture_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'elapsed_seconds':time.monotonic()-started,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'reference_sources':{str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (r/'reference').glob('*.py')},'limitations':['Independent high-precision pointwise values only','Input coordinates are exact binary64 words, time is the exact declared dyadic tick','No force-sampling or current-grid integration arithmetic qualification']}
(w/'p09-reduced-force-fixture-study.json').write_text(json.dumps(report,indent=2)+'\n')
