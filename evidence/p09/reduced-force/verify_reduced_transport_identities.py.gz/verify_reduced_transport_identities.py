"""Independent symbolic Cartesian derivation of the regular axisymmetric transport formulas."""
import hashlib,json,resource,time
from pathlib import Path
resource.setrlimit(resource.RLIMIT_AS,(512*1024*1024,512*1024*1024))
import sympy as s
started=time.monotonic()
x,y,z,t,w=s.symbols('x y z t w',real=True)
c,b,d,p,a=[s.Function(name)(w,z,t) for name in ['c','b','d','p','a']]
radius=x*x+y*y
lift=lambda expr:expr.subs(w,radius)
cart=lambda values:s.Matrix([x*values[0]-y*values[1],y*values[0]+x*values[1],values[2]])
u=cart([lift(c),lift(b),lift(d)])
variables=[x,y,z]
actual={
 'temporal':u.diff(t),
 'advective':u.jacobian(variables)*u,
 'viscous':-sum((u.diff(q,2) for q in variables),s.zeros(3,1)),
 'pressure':s.Matrix([s.diff(lift(p),q) for q in variables]),
}
expected={
 'temporal':cart([lift(f.diff(t)) for f in [c,b,d]]),
 'advective':cart([lift(c*c-b*b+2*w*c*c.diff(w)+d*c.diff(z)),lift(2*c*b+2*w*c*b.diff(w)+d*b.diff(z)),lift(2*w*c*d.diff(w)+d*d.diff(z))]),
 'viscous':cart([lift(-(8*f.diff(w)+4*w*f.diff(w,2)+f.diff(z,2))) for f in [c,b]]+[lift(-(4*d.diff(w)+4*w*d.diff(w,2)+d.diff(z,2)))]),
 'pressure':cart([lift(2*p.diff(w)),s.Integer(0),lift(p.diff(z))]),
}
checks={}
for name in actual:
 differences=[s.simplify(s.expand(expr)) for expr in actual[name]-expected[name]]
 assert differences==[0,0,0],(name,differences)
 checks[name]=[str(expr) for expr in differences]
stream_velocity=cart([lift(-a.diff(z)),lift(b),lift(2*a+2*w*a.diff(w))])
divergence=s.simplify(s.expand(sum(s.diff(stream_velocity[i],q) for i,q in enumerate(variables))))
assert divergence==0
checks['potential_divergence']=str(divergence)
report={'status':'passed','scope':'Exact symbolic Cartesian momentum identities for arbitrary regular c(w,z,t), b(w,z,t), d(w,z,t), p(w,z,t), w=x*x+y*y; viscosity one. Divergence identity for c=-a_z and d=2a+2w a_w.','checks':checks,'sympy_version':s.__version__,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'address_space_cap_bytes':512*1024*1024,'elapsed_seconds':time.monotonic()-started,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'limitations':['No floating-point error bound','No force-grid or trajectory/PDE qualification','No source-construction compiler claim']}
Path('/mnt/niva-array/nsbu-solver/work/p09-reduced-transport-symbolic.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
