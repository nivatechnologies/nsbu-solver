#!/usr/bin/env bash
set -euo pipefail
export PATH="$PATH:/mnt/niva-array/nsbu-solver/work/rust-tools/bin"
cargo fmt --all -- --check > ../reduced-alpha-format.log 2>&1
cargo clippy --workspace --all-targets --locked -- -D warnings -A dead_code > ../reduced-alpha-clippy.log 2>&1
rust-code-analysis-cli -p crates -m -O json > ../reduced-alpha-metrics.json
cargo +nightly-2026-03-03 llvm-cov --package nsbu-benchmarks --lib --test reduced_force --test reduced_force_allocation --example reduced_force_profile --branch --no-default-ignore-filename-regex --ignore-filename-regex '(/rustc/|/\.cargo/registry/|/\.rustup/toolchains/|/target/)' --json --output-path ../reduced-alpha-focused-coverage.json > ../reduced-alpha-focused-coverage.log 2>&1
/mnt/niva-array/nsbu-solver/.venv/bin/python - <<'PY'
import json
from pathlib import Path
paths=[*Path('crates/nsbu-benchmarks/src/reduced_force').rglob('*.rs'),*Path('crates/nsbu-benchmarks/tests').glob('reduced_force*.rs'),Path('crates/nsbu-benchmarks/examples/reduced_force_profile.rs')]
files={str(p.resolve()) for p in paths}
rows=[]
for line in Path('../reduced-alpha-metrics.json').read_text().splitlines():
    data=json.loads(line)
    if str(Path(data['name']).resolve()) in files: rows.append(line)
assert len(rows)==10,len(rows)
Path('../reduced-alpha-focused-metrics.json').write_text('\n'.join(rows)+'\n')
PY
/mnt/niva-array/nsbu-solver/.venv/bin/python quality/check_crap.py rust ../reduced-alpha-focused-metrics.json ../reduced-alpha-focused-coverage.json ../reduced-alpha-focused-crap.json > ../reduced-alpha-focused-crap.log 2>&1
RUSTDOCFLAGS='-D warnings' cargo doc --workspace --no-deps --locked > ../reduced-alpha-rustdoc.log 2>&1
