import hashlib, io, json, shutil, subprocess, tarfile, tempfile
from pathlib import Path
r=Path('/mnt/niva-array/nsbu-solver/work/p09-reduced-force-alpha');w=r.parent
scratch=Path(tempfile.mkdtemp(prefix='reduced-alpha-clean-',dir=w));clean=scratch/'nsbu-solver';clean.mkdir()
raw=subprocess.run(['git','archive','HEAD'],cwd=r,check=True,capture_output=True).stdout
with tarfile.open(fileobj=io.BytesIO(raw)) as archive: archive.extractall(clean,filter='data')
paths=[p.relative_to(r) for p in (r/'crates/nsbu-benchmarks/src/reduced_force').rglob('*.rs')]
paths += [Path(p) for p in ['crates/nsbu-benchmarks/src/lib.rs','crates/nsbu-benchmarks/Cargo.toml','crates/nsbu-benchmarks/tests/reduced_force.rs','crates/nsbu-benchmarks/tests/reduced_force_allocation.rs','crates/nsbu-benchmarks/tests/fixtures/reduced-force-words.tsv','crates/nsbu-benchmarks/examples/reduced_force_profile.rs','docs/REDUCED_FORCE.md']]
for p in paths: (clean/p).parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/p,clean/p)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources={str(p.relative_to(r)):sha(p) for folder in ['crates','reference','tools','quality','typings'] for p in (r/folder).rglob('*') if p.suffix in ['.rs','.py','.pyi']}
assert all(sha(clean/p)==digest for p,digest in sources.items())
original=w/'generate_reduced_force_fixtures.py';original_sha=sha(original)
text=original.read_text().replace("r=Path('/mnt/niva-array/nsbu-solver/work/p09-reduced-force-development')",f'r=Path({str(clean)!r})')
assert text!=original.read_text()
script=scratch/'generate_reduced_force_fixtures.py';script.write_text(text)
with (w/'reduced-alpha-clean-fixtures.log').open('w') as log:
 subprocess.run(['/mnt/niva-array/nsbu-solver/.venv/bin/python',str(script)],cwd=clean,stdout=log,stderr=subprocess.STDOUT,check=True)
fixture=Path('crates/nsbu-benchmarks/tests/fixtures/reduced-force-words.tsv');assert sha(clean/fixture)==sha(r/fixture)
report=json.loads((scratch/'p09-reduced-force-fixture-study.json').read_text())
assert report['status']=='passed'
original_report=json.loads((w/'p09-reduced-force-fixture-study.json').read_text())
assert report['samples']==original_report['samples'] and report['reference_sources']==original_report['reference_sources']
result={'status':'passed','clean_directory':str(clean),'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'overlay_paths':[str(p) for p in paths],'source_sha256':sources,'fixture_sha256':sha(clean/fixture),'original_generator_sha256':original_sha,'replay_generator_sha256':sha(script),'generator_change':'Only the checkout root path is substituted; original script and hash retained.','all_84_precision_studies_identical':True,'peak_rss_kib':report['peak_rss_kib'],'elapsed_seconds':report['elapsed_seconds']}
(w/'reduced-alpha-clean-reproduction.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='source_sha256'},indent=2))
