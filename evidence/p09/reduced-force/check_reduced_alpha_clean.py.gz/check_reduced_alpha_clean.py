import json,subprocess
from pathlib import Path
w=Path('/mnt/niva-array/nsbu-solver/work')
r=Path(json.loads((w/'reduced-alpha-clean-reproduction.json').read_text())['clean_directory'])
commands=[('tests',['cargo','test','-p','nsbu-benchmarks','--test','reduced_force','--test','reduced_force_allocation','--','--nocapture']),('unit-tests',['cargo','test','-p','nsbu-benchmarks','--lib','reduced_force']),('preflight',['cargo','run','--release','-p','nsbu-benchmarks','--example','reduced_force_profile','--','--dry-run']),('profile',['cargo','run','--release','-p','nsbu-benchmarks','--example','reduced_force_profile']),('package',['cargo','package','--workspace','--locked'])]
for name,command in commands:
 with (w/f'reduced-alpha-clean-{name}.log').open('w') as log: subprocess.run(command,cwd=r,stdout=log,stderr=subprocess.STDOUT,check=True)
 print(name,'passed',flush=True)
def numerical(path):
 return [line for line in path.read_text().splitlines() if line.startswith(('pointwise preflight','case=','comparison'))]
assert numerical(w/'reduced-alpha-clean-profile.log')==numerical(w/'reduced-alpha-profile.log')
result={'status':'passed','clean_directory':str(r),'commands':commands,'preflight_and_comparison_lines_equal':True,'note':'Elapsed timing and build paths are not compared; all four maximum force differences and preflight values reproduce exactly.'}
(w/'reduced-alpha-clean-checks.json').write_text(json.dumps(result,indent=2)+'\n')
