#!/usr/bin/env bash
set -euo pipefail
export PATH="$PATH:/mnt/niva-array/nsbu-solver/work/rust-tools/bin"
cargo fmt --all -- --check
cargo clippy --workspace --all-targets --locked -- -D warnings -A dead_code
RUSTDOCFLAGS='-D warnings' cargo doc --workspace --no-deps --locked
rust-code-analysis-cli -p crates -m -O json > /tmp/v2-probes-metrics.json
cargo +nightly-2026-03-03 llvm-cov clean --workspace
cargo +nightly-2026-03-03 llvm-cov --package nsbu-benchmarks --test v2_probe_family --branch --no-report
cargo +nightly-2026-03-03 llvm-cov --package nsbu-benchmarks --test v2_probe_family_allocation --branch --no-report
cargo +nightly-2026-03-03 llvm-cov --package nsbu-benchmarks --test v2_reconstructed_run --branch --no-report
cargo +nightly-2026-03-03 llvm-cov report --branch --json --output-path /tmp/v2-probes-coverage.json
jq -c 'select(.name | test("crates/nsbu-benchmarks/src/v2_experiment/probes/(mod|plan|report).rs$"))' /tmp/v2-probes-metrics.json > /tmp/v2-probes-focused-metrics.json
/mnt/niva-array/nsbu-solver/.venv/bin/python quality/check_crap.py rust /tmp/v2-probes-focused-metrics.json /tmp/v2-probes-coverage.json /tmp/v2-probes-focused-crap.json
