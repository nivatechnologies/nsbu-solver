#!/usr/bin/env bash
set -euo pipefail
export PATH="$PATH:/mnt/niva-array/nsbu-solver/work/rust-tools/bin"
cargo fmt --all -- --check
cargo clippy -p nsbu-benchmarks --lib --test v2_pressure_family --test v2_pressure_allocation --test v2_residual_family --test v2_residual_family_allocation --locked -- -D warnings -A dead_code
RUSTDOCFLAGS='-D warnings' cargo doc --workspace --no-deps --locked
rust-code-analysis-cli -p crates -m -O json > /tmp/v2-diagnostic-workers-metrics.json
jq -c 'select(.name | test("crates/nsbu-benchmarks/(src/v2_experiment/(pressure/(mod|plan|tests)|probes/residuals/(mod|plan|workspace))|tests/v2_(pressure_allocation|residual_family|residual_family_allocation)).rs$"))' /tmp/v2-diagnostic-workers-metrics.json > /tmp/v2-diagnostic-workers-focused-metrics.json
cargo +nightly-2026-03-03 llvm-cov clean --workspace
cargo +nightly-2026-03-03 llvm-cov --package nsbu-benchmarks --test v2_pressure_family --test v2_pressure_allocation --test v2_residual_family --test v2_residual_family_allocation --branch --no-report
cargo +nightly-2026-03-03 llvm-cov --package nsbu-benchmarks --lib --branch --no-report -- v2_experiment::pressure
cargo +nightly-2026-03-03 llvm-cov --package nsbu-benchmarks --lib --branch --no-report -- v2_experiment::probes::residuals::workspace::tests::zero_allowance_small_cap_wrong_domain_and_exhaustion_are_refused
cargo +nightly-2026-03-03 llvm-cov report --branch --no-default-ignore-filename-regex --ignore-filename-regex '(/rustc/|/\.cargo/registry/|/\.rustup/toolchains/|/target/)' --json --output-path /tmp/v2-diagnostic-workers-coverage.json
/mnt/niva-array/nsbu-solver/.venv/bin/python quality/check_crap.py rust /tmp/v2-diagnostic-workers-focused-metrics.json /tmp/v2-diagnostic-workers-coverage.json /tmp/v2-diagnostic-workers-focused-crap.json
