#!/usr/bin/env bash
set -euo pipefail
cargo +nightly-2026-03-03 llvm-cov report --branch --no-default-ignore-filename-regex --ignore-filename-regex '(/rustc/|/\.cargo/registry/|/\.rustup/toolchains/|/target/)' --json --output-path work/review-adapter-ddd-coverage-inclusive.json
python3 - <<'PY'
import json
p='work/review-adapter-ddd-coverage-inclusive.json'; d=json.load(open(p))
prefix='/mnt/niva-array/nsbu-solver/work/p09-review-offstage-reference/'
for f in d['data'][0]['files']:
    if f['filename'].startswith(prefix): f['filename']=f['filename'][len(prefix):]
json.dump(d,open('work/review-adapter-ddd-coverage-normalized.json','w'),indent=2)
PY
python3 -m quality.check_crap rust work/review-adapter-ddd-test-metrics.jsonl work/review-adapter-ddd-coverage-normalized.json work/review-adapter-ddd-test-crap.json
