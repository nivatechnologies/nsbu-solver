#!/usr/bin/env bash
set -euo pipefail
export PATH="$PATH:/mnt/niva-array/nsbu-solver/work/rust-tools/bin"
cargo fmt --all -- --check
cargo clippy --workspace --all-targets --locked -- -D warnings -A dead_code
RUSTDOCFLAGS='-D warnings' cargo doc --workspace --no-deps --locked
rust-code-analysis-cli -p crates -m -O json > /tmp/v2-balances-metrics.json
jq -c 'select(.name | test("crates/nsbu-benchmarks/src/v2_experiment/probes/balances/(mod|plan|quadrature).rs$|crates/nsbu-benchmarks/src/v2_experiment/probes/balances/quadrature/plan.rs$"))' /tmp/v2-balances-metrics.json > /tmp/v2-balances-focused-metrics.json
jq -c 'select(.name | test("crates/nsbu-benchmarks/(src/v2_experiment/probes/balances/|tests/v2_balance)"))' /tmp/v2-balances-metrics.json > /tmp/v2-balances-changed-metrics.json
cargo +nightly-2026-03-03 llvm-cov clean --workspace
cargo +nightly-2026-03-03 llvm-cov --package nsbu-benchmarks --test v2_balance_quadrature --test v2_balance_quadrature_allocation --branch --no-report
cargo +nightly-2026-03-03 llvm-cov --package nsbu-benchmarks --lib --branch --no-report -- v2_experiment::probes::balances::tests::failed_late_history_update_rolls_back_all_levels_and_terminates
cargo +nightly-2026-03-03 llvm-cov report --branch --json --output-path /tmp/v2-balances-coverage.json
/mnt/niva-array/nsbu-solver/.venv/bin/python quality/check_crap.py rust /tmp/v2-balances-focused-metrics.json /tmp/v2-balances-coverage.json /tmp/v2-balances-focused-crap.json
