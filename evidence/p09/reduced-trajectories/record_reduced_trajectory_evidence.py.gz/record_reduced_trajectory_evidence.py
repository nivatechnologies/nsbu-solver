import datetime, gzip, hashlib, json, platform, re
from pathlib import Path

r = Path('/mnt/niva-array/nsbu-solver/work/p09-reduced-trajectory-development')
w = r.parent
e = r/'evidence/p09/reduced-trajectories'
e.mkdir(parents=True, exist_ok=True)
sha = lambda raw: hashlib.sha256(raw).hexdigest()
def write(name, data): (e/name).write_text(json.dumps(data, indent=2)+'\n')
def load(name): return json.loads((w/('reduced-trajectory-'+name)).read_text())
source = {str(p.relative_to(r)):sha(p.read_bytes()) for folder in ('crates','reference','quality','tools','typings') for p in (r/folder).rglob('*') if p.suffix in ('.rs','.py','.pyi')}
rust = [p for p in source if p.endswith('.rs')]
python = [p for p in source if not p.endswith('.rs')]
focus_paths = ['crates/nsbu-benchmarks/tests/reduced_trajectory.rs', 'crates/nsbu-benchmarks/tests/reduced_trajectory_support.rs']
assert len(rust)==364 and len(python)==98
def walk(node):
    yield node
    for child in node['spaces']: yield from walk(child)
nodes=[n for line in (w/'reduced-trajectory-metrics.json').read_text().splitlines() for n in walk(json.loads(line))]
functions=[n for n in nodes if n['kind']=='function']
maxima={'cyclomatic':max(n['metrics']['cyclomatic']['sum'] for n in functions), 'cognitive':max(n['metrics']['cognitive']['sum'] for n in functions), 'halstead_function_and_file':max(n['metrics']['halstead']['difficulty'] or 0 for n in nodes), 'physical_file_lines':max(len((r/p).read_text().splitlines()) for p in rust)}
for key,cap in [('cyclomatic',22),('cognitive',22),('halstead_function_and_file',80),('physical_file_lines',500)]: assert maxima[key]<cap
files=[f for f in load('focused-coverage.json')['data'][0]['files'] if str(Path(f['filename']).relative_to(r)) in focus_paths]
assert len(files)==2
coverage={}
for key in ('lines','branches'):
    count=sum(f['summary'][key]['count'] for f in files);covered=sum(f['summary'][key]['covered'] for f in files)
    coverage[key]={'count':count,'covered':covered,'percent':100*covered/count if count else None}
    assert count == 0 or coverage[key]['percent']>=80
crap=load('focused-crap.json')['maximum'];assert crap<25
lexical=[f'{p}:{i}:{line}' for p in rust for i,line in enumerate((r/p).read_text().splitlines(),1) if re.search(r'\b(Any|unknown)\b',line)]
escapes=[line for line in lexical if not line.split(':',2)[2].lstrip().startswith('//')];assert not escapes
write('type-identifier-scan.json',{'lexical_matches':lexical,'code_matches':escapes,'scope':rust,'method':'CI lexical rule; compiler and strict Clippy verify concrete inferred types.'})
raw=(w/'reduced-trajectory-root-tests.log').read_text();assert '2 passed; 0 failed' in raw
pattern=r'method=(\w+) steps=32 endpoint=4096 maximum_pair=(\S+) endpoint_fixture_max_original=(\S+) endpoint_fixture_max_reduced=(\S+) provider_consumption=\[(\d+), (\d+), (\d+)\] cumulative_work=\[(\d+),(\d+)\]'
rows=re.findall(pattern,raw);assert len(rows)==2
measurements={}
for method,pair,original,reduced,calls,work,transforms,cumulative_a,cumulative_b in rows:
    assert float(pair)<5e-12 and max(float(original),float(reduced))<5e-13
    assert cumulative_a==cumulative_b
    measurements[method]={'maximum_each_commit_scaled_pair_difference':float(pair),'endpoint_scaled_fixture_difference_original':float(original),'endpoint_scaled_fixture_difference_reduced':float(reduced),'last_attempt_consumption':[int(calls),int(work),int(transforms)],'cumulative_provider_work_per_branch':int(cumulative_a),'total_rhs_calls_per_branch':32*int(calls),'total_scalar_transforms_per_branch':32*int(transforms)}
write('source-sha256.json',source)
write('summary.json',{'package':'P09','increment':'independent reduced-provider CM/HO trajectories',
    'status':'focused numerical/new-test quality and whole-workspace static/lint gates passed; complete source-matched hosted checks pending',
    'generated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'parent_commit':'6170341c42a64348c7d99bdfd4fc3653454f22a8','source_inventory':'source-sha256.json',
    'rust_source_files':len(rust),'added_source_files':focus_paths,'production_source_changes':0,
    'focused_tests':2,'focused_coverage':coverage,'focused_crap_maximum':crap,'whole_workspace_static_maxima':maxima,
    'quality_scope':'Coverage and CRAP cover both added numerical test/helper files. LLVM reports no instrumented branches in these files; branch percentage is not applicable, not100%. The whole-workspace branch gate remains required in hosted CI. Whole-source static/lint/size/type checks are fresh. Production source is unchanged from6170341.',
    'profile':{'retained':[4,4,4],'force_samples':[4,4,4],'clock_exponent':-20,'target_ticks':8192,'step_ticks':128,'endpoint_ticks':4096,'endpoint_rational':'1/256','attempts_per_branch':32,'absolute_tolerances':[1e-5,1e-4],'relative_tolerances':[1e-5,1e-5],'advective_limit':0.3,'joint_storage_cap_bytes':8388608},
    'measured':measurements,
    'numerical_checks':['Original and reduced providers each own separately allocated states beginning at exact rest; both CM and HO reach all32 independent commits.','Every retained coefficient is compared after each commit at scaled component tolerance5e-12; both complete endpoint fields match preserved independent80/120-digit DFT fixtures at5e-13.','Committed coefficient words remain unchanged through each attempt; only accepted tokens commit candidates. Exact elapsed and remaining clocks and accepted counts agree at every step.','Both complete resource plans, provider limits, checked joint storage and32-attempt work bounds are admitted before constructing either provider/state; cap-minus-one provider refusals remain explicit.','Actual RHS calls and scalar transforms match method declarations at every attempt; cumulative provider work remains within the admitted finite bound.','An actual reduced-provider rejection keeps committed state/clock/count unchanged while consuming positive bounded work.'],
    'fixture_sha256':{name:sha((r/'crates/nsbu-benchmarks/tests/fixtures'/name).read_bytes()) for name in ['concentrating-n4.tsv','concentrating-ho-n4.tsv']},
    'execution_profile':{'rust':'1.94.0','coverage_toolchain':'nightly-2026-03-03','cargo_llvm_cov':'0.9.1','rust_code_analysis':'0.0.25','host':platform.platform(),'cargo_lock_sha256':sha((r/'Cargo.lock').read_bytes()),'manifest_sha256':{p:sha((r/p).read_bytes()) for p in ['Cargo.toml','crates/nsbu-benchmarks/Cargo.toml','rust-toolchain.toml']},'case_sha256':sha((r/'benchmarks/similarity-mms-v2.json').read_bytes()),'test_opt_level':2,'test_debug_assertions':True,'test_overflow_checks':True},
    'solid_review':'Test admission and typed numerical ownership are separate from paired evolution and independent fixture comparison. Existing PrescribedForce/attempt/commit interfaces are exercised without production changes or analytical state assignment.',
    'unchanged_python':{'source_files':98,'retained_tests':220},
    'informational_findings':'Mutation/duplication sweeps were not rerun. Strict Clippy permits only informational shared-helper dead_code warnings. No type-escape code identifiers found.',
    'limitations':['N4/M4 is spatially and force-sampling unresolved. Agreement with a same-grid high-precision trajectory is not PDE convergence.','No trajectory performance timing is measured.','The default Run/ForceSettings/CLI/checkpoint paths still use the original provider; explicit arithmetic identity and runtime integration remain separate work.','P08/P09/P10 remain incomplete.'],
    'accepted_pde_windows':0,'artifact_inventory':'artifact-sha256.json'})
artifacts={}
for name in ['format.log','clippy-final.log','metrics.json','focused-metrics.json','focused-coverage.json','focused-coverage.log','focused-crap.json','root-tests.log']:
    path=w/('reduced-trajectory-'+name);raw=path.read_bytes();data=gzip.compress(raw,mtime=0);filename=name+'.gz';(e/filename).write_bytes(data)
    artifacts[filename]={'bytes':len(data),'sha256':sha(data),'uncompressed_bytes':len(raw),'uncompressed_sha256':sha(raw)}
for name in ['check_reduced_trajectory_focused.sh','record_reduced_trajectory_evidence.py']:
    raw=(w/name).read_bytes();data=gzip.compress(raw,mtime=0);filename=name+'.gz';(e/filename).write_bytes(data)
    artifacts[filename]={'bytes':len(data),'sha256':sha(data),'uncompressed_bytes':len(raw),'uncompressed_sha256':sha(raw)}
write('artifact-sha256.json',artifacts)
print(json.dumps({'coverage':coverage,'crap':crap,'maxima':maxima,'measurements':measurements},indent=2))
