#!/usr/bin/env bash
set -euo pipefail
export PATH="$PATH:/mnt/niva-array/nsbu-solver/work/rust-tools/bin"
cargo fmt --all -- --check > ../reduced-trajectory-format.log 2>&1
cargo clippy --workspace --all-targets --locked -- -D warnings -A dead_code > ../reduced-trajectory-clippy-final.log 2>&1
rust-code-analysis-cli -p crates -m -O json > ../reduced-trajectory-metrics.json
jq -se '[.. | objects | select(.kind? == "function") | .metrics.cyclomatic.sum] | max < 22' ../reduced-trajectory-metrics.json
jq -se '[.. | objects | select(.kind? == "function") | .metrics.cognitive.sum] | max < 22' ../reduced-trajectory-metrics.json
jq -se '[.. | objects | select(has("metrics")) | .metrics.halstead.difficulty | select(. != null)] | max < 80' ../reduced-trajectory-metrics.json
cargo +nightly-2026-03-03 llvm-cov --package nsbu-benchmarks --test reduced_trajectory --branch --no-default-ignore-filename-regex --ignore-filename-regex '(/rustc/|/\.cargo/registry/|/\.rustup/toolchains/|/target/)' --json --output-path ../reduced-trajectory-focused-coverage.json > ../reduced-trajectory-focused-coverage.log 2>&1
/mnt/niva-array/nsbu-solver/.venv/bin/python - <<'PY'
import json
from pathlib import Path
paths={str(p.resolve()) for p in Path('crates/nsbu-benchmarks/tests').glob('reduced_trajectory*.rs')}
rows=[line for line in Path('../reduced-trajectory-metrics.json').read_text().splitlines() if str(Path(json.loads(line)['name']).resolve()) in paths]
assert len(rows)==2
Path('../reduced-trajectory-focused-metrics.json').write_text('\n'.join(rows)+'\n')
PY
/mnt/niva-array/nsbu-solver/.venv/bin/python quality/check_crap.py rust ../reduced-trajectory-focused-metrics.json ../reduced-trajectory-focused-coverage.json ../reduced-trajectory-focused-crap.json > ../reduced-trajectory-focused-crap.log 2>&1
