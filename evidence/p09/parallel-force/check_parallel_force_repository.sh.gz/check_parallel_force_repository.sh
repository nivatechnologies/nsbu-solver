#!/usr/bin/env bash
set -euo pipefail
prefix=../p09-parallel-force-
rg --files crates -g '*.rs' | sort > "${prefix}source-files.txt"
while IFS= read -r path; do awk 'END { exit !(NR < 500) }' "$path"; done < "${prefix}source-files.txt"
rg -n '\b(Any|unknown)\b' crates -g '*.rs' > "${prefix}type-lexical.log" || test "$?" -eq 1
awk '!/^[[:space:]]*\/\// && /(^|[^[:alnum:]_])(Any|unknown)([^[:alnum:]_]|$)/ { print FILENAME ":" FNR ":" $0; found=1 } END { exit found }' $(cat "${prefix}source-files.txt") > "${prefix}type-escapes.log"
RUSTDOCFLAGS='-D warnings' cargo doc --workspace --no-deps > "${prefix}rustdoc.log" 2>&1
package_target=$(mktemp -d)
cargo package --workspace --locked --allow-dirty --target-dir "$package_target" > "${prefix}package.log" 2>&1
/mnt/niva-array/nsbu-solver/.venv/bin/python tools/check_repository.py > "${prefix}repository.json"
/mnt/niva-array/nsbu-solver/.venv/bin/python -m unittest discover -s tools/tests -v > "${prefix}bootstrap.log" 2>&1
/mnt/niva-array/nsbu-solver/.venv/bin/python tools/verify_design.py --output "${prefix}design.json" > "${prefix}design.log" 2>&1
