import hashlib,json,re,subprocess
from pathlib import Path
r=Path('/mnt/niva-array/nsbu-solver/work/p09-parallel-force-development');w=r.parent;c=w/'p09-parallel-force-clean-source'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources={str(p.relative_to(r)):sha(p) for folder in ('crates','reference','quality','tools','typings') for p in (r/folder).rglob('*') if p.suffix in ('.rs','.py','.pyi')}
assert len(sources)==413,len(sources)
for p,h in sources.items():assert sha(c/p)==h,p
with (w/'p09-parallel-force-clean-tests.log').open('w') as log:
 for args in [['--lib','provider::parallel'],['--test','parallel_force','--test','parallel_force_allocation','--example','parallel_force_profile']]:
  subprocess.run(['cargo','test','-p','nsbu-benchmarks',*args],cwd=c,stdout=log,stderr=subprocess.STDOUT,check=True)
outputs={}
for role,root in [('development',r),('clean',c)]:
 with (w/('p09-parallel-force-'+role+'-build.log')).open('w') as log:
  subprocess.run(['cargo','build','--release','-p','nsbu-benchmarks','--example','parallel_force_profile'],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
 for n in [16,32]:
  for name,args in [('preflight',['--dry-run']),('profile',[])]:
   raw=subprocess.check_output([str(root/'target/release/examples/parallel_force_profile'),str(n),*args],cwd=root)
   key=name+'-n'+str(n)
   (w/('p09-parallel-force-'+role+'-'+key+'.log')).write_bytes(raw)
   normalized=re.sub(rb'seconds=[0-9.]+',b'seconds=TIMING',raw)
   if role=='development':outputs[key]=normalized
   else:assert outputs[key]==normalized,key
proof={'export':'complete committed public Git index without metadata','sources':sources,
 'manifests':{p:sha(r/p) for p in ('Cargo.toml','Cargo.lock','crates/nsbu-benchmarks/Cargo.toml')},
 'tests':'6 focused harness tests plus the isolated parallel allocation executable',
 'public_output':'N16/N32 preflights byte-identical; every serial/parallel force hash, work count and storage value identical after removing only measured elapsed seconds',
 'normalized_output_sha256':{k:hashlib.sha256(v).hexdigest() for k,v in outputs.items()}}
(w/'p09-parallel-force-clean-source-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
print('413 maintained source hashes, 6 focused tests, allocation and complete N16/N32 numerical profiles reproduce.')
