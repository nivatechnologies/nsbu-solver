#!/usr/bin/env bash
set -u
/mnt/niva-array/nsbu-solver/work/node-tools/node_modules/.bin/jscpd crates --format rust --min-lines 5 --min-tokens 50 --threshold 0 --reporters json --output ../p09-parallel-force-duplicates > ../p09-parallel-force-duplicates.log 2>&1
printf '%s\n' "$?" > ../p09-parallel-force-duplicates.exit
cargo clippy --workspace --all-targets -- -D warnings > ../p09-parallel-force-dead-code.log 2>&1
printf '%s\n' "$?" > ../p09-parallel-force-dead-code.exit
