import concurrent.futures
import hashlib
import json
import multiprocessing
import os
from pathlib import Path
import shutil
import shlex
import sys
import subprocess
import time

ROOT=Path.cwd()
WORK=ROOT/'work/cosmic-final-reference'
PYTHON=ROOT/'.venv/bin/python'

def initialize(queue):
    os.chdir(queue.get())

def execute(job):
    from cosmic_ray.mutating import mutate_and_test
    from cosmic_ray.work_item import MutationSpec
    mutations=[MutationSpec(module_path=Path(m['module_path']),operator_name=m['operator_name'],
                            occurrence=m['occurrence'],start_pos=tuple(m['start_pos']),
                            end_pos=tuple(m['end_pos'])) for m in job['mutations']]
    suite = 'tools/tests' if job['mutations'][0]['module_path'].startswith('tools/') else 'reference/tests'
    module=job['mutations'][0]['module_path']
    preferred={'reference/scalar.py':'test_coefficient_work_limits.py',
      'reference/steps.py':'test_coefficient_work_limits.py',
      'reference/dft.py':'test_spectral_interactions.py',
      'reference/verify_fields.py':'test_field_contracts.py',
      'reference/verify_steps.py':'test_numerical_contracts.py',
      'reference/verify_sampling.py':'test_sampling_contracts.py',
      'reference/verify_trajectory.py':'test_trajectory_contracts.py',
      'reference/jets.py':'test_jet_algebra.py'}.get(module,'')
    files=sorted(Path(suite).glob('test_*.py'),key=lambda p:(p.name!=preferred,p.name))
    assert files and all(p.is_file() for p in files)
    commands=[]
    if suite == 'reference/tests':
        commands.append([str(PYTHON),'-m','pytest','-q','reference/tests/test_driver_imports.py','reference/tests/test_bounded_reference_work.py','-x'])
    commands.append([str(PYTHON),'-m','pytest','-q',*[str(p) for p in files],'-x'])
    code='import subprocess,sys\nfor command in '+repr(commands)+':\n result=subprocess.run(command)\n if result.returncode: sys.exit(result.returncode)\n'
    command=str(PYTHON)+' -c '+shlex.quote(code)
    result=mutate_and_test(mutations=mutations,test_command=command,timeout=180.0)
    return {'job_id':job['job_id'],'mutations':job['mutations'],
            'test_command':command,'worker_outcome':result.worker_outcome.value,
            'test_outcome':result.test_outcome.value if result.test_outcome else None,
            'diff':result.diff,'output':result.output}

if __name__=='__main__':
    subprocess.run([str(PYTHON),'-m','pytest','-q'],cwd=ROOT,check=True)
    queue=multiprocessing.Queue()
    for i in range(32):
        target=WORK/f'worker-{i}'
        shutil.copytree(ROOT,target,dirs_exist_ok=True,ignore=shutil.ignore_patterns('.git','.venv','work','mutants','__pycache__','.pytest_cache','.complexipy_cache'))
        queue.put(str(target))
    (WORK/'source-hashes.json').write_text(json.dumps({str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for d in ('reference','tools') for p in (ROOT/d).rglob('*.py')},indent=2))
    jobs=[json.loads(line)[0] for line in (WORK/'all-inventory.jsonl').read_text().splitlines()]
    print('generated',len(jobs),flush=True)
    start=time.monotonic()
    with concurrent.futures.ProcessPoolExecutor(max_workers=32,initializer=initialize,initargs=(queue,)) as pool, (WORK/'all-results.jsonl').open('w') as output:
        futures=[pool.submit(execute,job) for job in jobs]
        for i,future in enumerate(concurrent.futures.as_completed(futures),1):
            result=future.result()
            output.write(json.dumps(result)+'\n');output.flush()
            if i%50==0:print('completed',i,'seconds',round(time.monotonic()-start,1),flush=True)
    print('complete',len(jobs),flush=True)
