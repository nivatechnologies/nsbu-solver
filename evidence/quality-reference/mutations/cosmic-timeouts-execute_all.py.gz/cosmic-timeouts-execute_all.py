import concurrent.futures
import hashlib
import json
import multiprocessing
import os
from pathlib import Path
import shutil
import sys
import subprocess
import time

ROOT=Path.cwd()
WORK=ROOT/'work/cosmic-timeouts'
PYTHON=ROOT/'.venv/bin/python'

def initialize(queue):
    os.chdir(queue.get())

def execute(job):
    from cosmic_ray.mutating import mutate_and_test
    from cosmic_ray.work_item import MutationSpec
    mutations=[MutationSpec(module_path=Path(m['module_path']),operator_name=m['operator_name'],
                            occurrence=m['occurrence'],start_pos=tuple(m['start_pos']),
                            end_pos=tuple(m['end_pos'])) for m in job['mutations']]
    suite = 'tools/tests' if job['mutations'][0]['module_path'].startswith('tools/') else 'reference/tests'
    module = job['mutations'][0]['module_path']
    first = {'reference/scalar.py':'reference/tests/test_reference.py',
             'reference/jets.py':'reference/tests/test_jet_algebra.py',
             'reference/dft.py':'reference/tests/test_dft_steps.py',
             'reference/steps.py':'reference/tests/test_dft_steps.py'}.get(module,'')
    command = f'{PYTHON} -m pytest -q {first} {suite} -x'
    result=mutate_and_test(mutations=mutations,test_command=command,timeout=180.0)
    return {'job_id':job['job_id'],'mutations':job['mutations'],
            'test_command':command,'worker_outcome':result.worker_outcome.value,
            'test_outcome':result.test_outcome.value if result.test_outcome else None,
            'diff':result.diff,'output':result.output}

if __name__=='__main__':
    subprocess.run([str(PYTHON),'-m','pytest','-q'],cwd=ROOT,check=True)
    queue=multiprocessing.Queue()
    for i in range(16):
        target=WORK/f'worker-{i}'
        shutil.copytree(ROOT,target,dirs_exist_ok=True,ignore=shutil.ignore_patterns('.git','.venv','work','mutants','__pycache__','.pytest_cache','.complexipy_cache'))
        queue.put(str(target))
    (WORK/'source-hashes.json').write_text(json.dumps({str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for d in ('reference','tools') for p in (ROOT/d).rglob('*.py')},indent=2))
    jobs=[json.loads(line)[0] for line in (WORK/'all-inventory.jsonl').read_text().splitlines()]
    print('generated',len(jobs),flush=True)
    start=time.monotonic()
    with concurrent.futures.ProcessPoolExecutor(max_workers=16,initializer=initialize,initargs=(queue,)) as pool, (WORK/'all-results.jsonl').open('w') as output:
        futures=[pool.submit(execute,job) for job in jobs]
        for i,future in enumerate(concurrent.futures.as_completed(futures),1):
            result=future.result()
            output.write(json.dumps(result)+'\n');output.flush()
            if i%50==0:print('completed',i,'seconds',round(time.monotonic()-start,1),flush=True)
    print('complete',len(jobs),flush=True)
